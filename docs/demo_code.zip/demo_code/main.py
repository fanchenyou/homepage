import os
import argparse
import numpy as np
import random
from trainer import *
from models.model_trans_sequence_public import *
from loader.public.public_stock_sequence_dataset import *

if __name__ == '__main__':
    desc = 'the attentional lstm model'
    parser = argparse.ArgumentParser(description=desc)
    parser.add_argument('-d', '--dset', help='dataset name', type=str, default='kdd17',
                        choices=['kdd17', 'acl18'])
    parser.add_argument('--hl', help='length of hist', type=int, default=5)
    parser.add_argument('--fl', help='length of future', type=int, default=5)
    parser.add_argument("--test", default=False, action='store_true')
    parser.add_argument("--backtest", default=False, action='store_true')
    parser.add_argument('-u', '--unit', help='number of hidden units in lstm', type=int, default=32)
    parser.add_argument('-l2', '--alpha_l2', type=float, default=3e-3, help='alpha for l2 regularizer')
    parser.add_argument('-la', '--beta_adv', type=float, default=5e-1, help='beta for adverarial loss')
    parser.add_argument('-nw', '--n_worker', type=int, default=0,
                        help='manually set number of workers')
    parser.add_argument('-le', '--epsilon_adv', type=float, default=1e-2,
                        help='epsilon to control the scale of noise')
    parser.add_argument('-s', '--step', help='steps to make prediction',
                        type=int, default=1)
    parser.add_argument('-b', '--batch_size', help='batch size', type=int,
                        default=96)
    parser.add_argument('-e', '--epoch', help='epoch', type=int, default=1000)
    parser.add_argument('--lr', help='learning rate', type=float, default=3e-4)
    parser.add_argument('--tp', type=int, default=206)
    parser.add_argument('--att_tp', type=int, default=3)
    parser.add_argument('-ly', '--layer', type=int, default=2, help='how many layers of Transformer encoder')
    parser.add_argument('-w', '--week', type=int, default=0, help='use week day data')
    parser.add_argument('-v', '--adv', type=int, default=0,
                        help='adversarial training')
    parser.add_argument('-hi', '--hinge_lose', type=int, default=1,
                        help='use hinge lose')
    parser.add_argument('-rl', '--reload', type=int, default=0,
                        help='use pre-trained parameters')
    parser.add_argument('--gpu', default='0', type=str, help='id(s) for CUDA_VISIBLE_DEVICES')
    parser.add_argument('--model_dir', type=str, default='', help='path of test models')

    args = parser.parse_args()
    print(args)

    # Setup seeds
    # seed = 168
    random_data = os.urandom(4)
    seed = int.from_bytes(random_data, byteorder="big")
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)

    # Use CUDA
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
    use_cuda = torch.cuda.is_available()

    n_worker = 8
    n_daily_worker = n_worker // 2
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_cpu_test = False
    TRAIN_FLAG, VAL_FLAG, TEST_FLAG = 0, 1, 2

    if torch.cuda.is_available():
        batch_size = 128
        check_mode = False  # whether check minute, only supported for partial data
        if args.n_worker > 0:
            n_worker = args.n_worker
            n_daily_worker = n_worker // 2
            print('Manually set n_worker %d' % (n_worker,))
    else:
        batch_size = 64
        n_worker = 1
        n_daily_worker = 1
        check_mode = True
        use_cpu_test = True

    save_interval = 10
    val_interval = 5
    test_interval = 1
    train_display_interval = 1000
    val_display_interval = 3000

    dset = args.dset

    if 'acl18' in dset:
        # total 86 stocks
        K_top = 8  # took %10
        feat_dim = 11
        # tra_date = '2014-01-02'
        # val_date = '2015-08-03'
        # tes_date = '2015-10-01'

    elif 'kdd17' in dset:
        K_top = 5  # 50 stocks -> 5
        feat_dim = 11
        # tra_date = '2007-01-03'
        # val_date = '2015-01-02'
        # tes_date = '2016-01-04'

    else:
        raise 'Not implemented'

    model_type = args.tp
    att_type = args.att_tp

    # TODO: check this
    feat_dim = 11
    feat_ind_dim = 11  # ['OPEN', 'HIGH', 'LOW', 'CLOSE', 'VOLUME', 'AMT']

    hist_len = args.hl
    future_len = args.fl
    print('hist/future length %d/%d' % (hist_len, future_len))

    total_len = hist_len + future_len
    num_classes = 3

    if args.test or args.backtest:
        save_dir = None
    else:
        run_id = datetime.datetime.now().strftime('%m-%d-%H-%M')
        # training
        result_dset_path = "results/%s/trans" % (args.dset,)
        os.makedirs(result_dset_path, exist_ok=True)
        save_dir = os.path.join("%s/%s_tp%d_l%d_at%d_hl%d_fl%d" % (
            result_dset_path, run_id, model_type, args.layer, att_type, hist_len, future_len))
        os.makedirs(save_dir, exist_ok=True)
        print('Save dir %s' % (save_dir,))

    parameters = {
        'unit': int(args.unit),
        'alp': float(args.alpha_l2),
        'bet': float(args.beta_adv),
        'eps': float(args.epsilon_adv),
        'lr': float(args.lr),
        'val_interval': int(val_interval),
        'save_interval': int(save_interval),
        'train_display_interval': int(train_display_interval),
        'val_display_interval': int(val_display_interval),
        'save_dir': save_dir,
        'num_classes': int(num_classes),
    }

    trainloader = valloader = testloader = dailyloader = None
    if args.test:
        test_dataset = public_stock_dataset(dset, TEST_FLAG, hist_len, future_len, K_top, test_interval)

        testloader = data.DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=n_worker,
                                     pin_memory=True, drop_last=False)
        print('Number of trading days in test', len(test_dataset))
        print('Number of batches in test', len(testloader))
        num_stock = test_dataset.num_stock

    elif args.backtest:
        # the test interval is set to 1
        test_interval = 1
        test_dataset = public_stock_dataset_backtest(dset, TEST_FLAG, hist_len, future_len, K_top, test_interval)
        testloader = data.DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=n_worker,
                                     pin_memory=True, drop_last=False)
        print('Number of trading days in test', len(test_dataset))
        print('Number of batches in backtest', len(testloader))
        num_stock = test_dataset.num_stock

    else:
        train_dataset = public_stock_dataset(dset, TRAIN_FLAG, hist_len, future_len, K_top)
        daily_dataset = public_stock_dataset(dset, TRAIN_FLAG, hist_len, future_len, K_top, ranking_mode=True)

        # for two-month val/test, there are ~43 days for trading
        val_dataset = public_stock_dataset(dset, VAL_FLAG, hist_len, future_len, K_top, test_interval)

        trainloader = data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=n_worker,
                                      pin_memory=True, drop_last=True)
        dailyloader = data.DataLoader(daily_dataset, batch_size=1, shuffle=True, num_workers=n_worker,
                                      pin_memory=True, drop_last=True)
        valloader = data.DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=n_worker,
                                    pin_memory=True, drop_last=False)
        print('Number of trading days in train/val', len(train_dataset), len(val_dataset))
        print('Number of batches in train/val', len(trainloader), len(valloader))
        num_stock = train_dataset.num_stock

    if model_type == 206:
        # same with 202, with additional quantile loss
        fin_forecast_trainer = DTML_Sequence_Quantile_v7_Trainer(
            args, K_top, feat_dim, num_stock, hist_len, future_len,
            parameters, trainloader, valloader, testloader,
            device, args.step, args.epoch, args.batch_size,
            init_model_func=DTMLNet_Sequence_Quantile_Regression_v5_public,
            attention_type=args.att_tp,
            enc_dec_type='fusion'
        )
        fin_forecast_trainer.init_model()
        fin_forecast_trainer.trainloader_batch = dailyloader

    load_model_flag = False

    if len(args.model_dir) > 0:
        assert os.path.isdir(args.model_dir) or os.path.isfile(args.model_dir)
        if os.path.isdir(args.model_dir):
            filepath = os.path.join(args.model_dir, "best_model.pth")
            if use_cpu_test:
                checkpoint = torch.load(filepath,map_location = torch.device('cpu'))
            else:
                checkpoint = torch.load(filepath)
            print('Load', filepath)
        else:
            if use_cpu_test:
                checkpoint = torch.load(args.model_dir,map_location = torch.device('cpu'))
            else:
                checkpoint = torch.load(args.model_dir)
            print('Load', args.model_dir)

        fin_forecast_trainer.model.load_state_dict(checkpoint['model_state'])

    if args.test:
        fin_forecast_trainer.evaluate()
    elif args.backtest:
        fin_forecast_trainer.backtest()
    else:
        fin_forecast_trainer.train()
