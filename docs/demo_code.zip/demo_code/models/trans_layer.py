import os
import sys
import torch
from torch import nn
from torch.nn import functional as F

from .transformer.Layers import EncoderLayer, DecoderLayer
from .transformer.Models import PositionalEncoding
from .utils import init_linear, PositionalEncoding_v2, get_subsequent_mask


class Decoder_module(nn.Module):
    def __init__(self, embed_dim_total, hidden_size, hist_len, future_len, d_inner, n_layers, n_head, d_k,
                 d_v, dropout):
        # d_word_vec, n_layers, n_head, d_k, d_v,
        #             d_model, d_inner, pad_idx,  dropout=0.1, scale_emb=False
        super(Decoder_module, self).__init__()

        # target is 6, index is 7
        # self.input_size = feature_dim
        self.embed_dim_total = embed_dim_total
        self.hist_len = hist_len
        self.n_layers = n_layers
        self.hidden_size = hidden_size
        self.future_len = future_len

        # main-stream
        # self.linear_0 = nn.Linear(self.input_size, hidden_size)
        # dim_layer_1 = hidden_size + embed_dim_total
        self.linear_1 = nn.Linear(embed_dim_total, hidden_size)
        self.position_enc = PositionalEncoding(hidden_size, n_position=future_len)
        self.dropout = nn.Dropout(p=dropout)
        self.layer_norm = nn.LayerNorm(hidden_size, eps=1e-6)

        # auxiliary-stream
        dim_layer_1 = hidden_size + embed_dim_total
        self.linear_aux = nn.Linear(dim_layer_1, hidden_size)

        # https://github.com/jadore801120/attention-is-all-you-need-pytorch/blob/132907dd272e2cc92e3c10e6c4e783a87ff8893d/transformer/Models.py#L102
        self.layer_stack = nn.ModuleList([
            DecoderLayer(hidden_size, d_inner, n_head, d_k, d_v, dropout=dropout)
            for _ in range(n_layers)])

    def init_weights(self):
        """Initialize weights."""
        # init_linear(self.linear_0)
        # init_linear(self.linear_1)
        pass

    def forward(self, dec_input, enc_output):
        # future embedding is decoder input
        # print(dec_input.size(),'---2')
        # dec_input = self.dropout(dec_input)
        xz1 = F.relu(self.linear_1(dec_input))
        dec_output = self.dropout(self.position_enc(xz1))
        dec_output = self.layer_norm(dec_output)

        for dec_layer in self.layer_stack:
            # dec_output, dec_slf_attn, dec_enc_attn = \
            #     dec_layer(dec_output, enc_output, slf_attn_mask=trg_mask)
            # print(dec_output.size(), enc_output.size())
            # dec_output: [B, fut, 32]
            # enc_output: [B, hist, 32]
            dec_output, _, _ = dec_layer(dec_output, enc_output, slf_attn_mask=None)

        return dec_output

    def forward_masked_auxiliary(self, dec_input_ft, dec_input_embed, enc_output, use_trg_mask=True):
        # future embedding is decoder input
        # print(dec_input.size(),'---2')
        # dec_input = self.dropout(dec_input)
        xz0 = torch.cat([dec_input_ft, dec_input_embed], dim=-1)
        xz1 = F.relu(self.linear_aux(xz0))
        dec_output = self.dropout(self.position_enc(xz1))
        dec_output = self.layer_norm(dec_output)

        # https://github.com/jadore801120/attention-is-all-you-need-pytorch/blob/132907dd272e2cc92e3c10e6c4e783a87ff8893d/transformer/Models.py#L192
        # self_attn_mask is future mask, dont peek into future
        trg_mask = None
        if use_trg_mask:
            trg_mask = get_subsequent_mask(dec_output.size(1), dec_output.device)

        for dec_layer in self.layer_stack:
            # dec_output, dec_slf_attn, dec_enc_attn = \
            #     dec_layer(dec_output, enc_output, slf_attn_mask=trg_mask)
            dec_output, _, _ = dec_layer(dec_output, enc_output, slf_attn_mask=trg_mask)

        return dec_output


class Encoder_module_v2_rank(nn.Module):
    def __init__(self, embed_size, hidden_size, hist_len, d_inner, n_layers, n_head, d_k,
                 d_v, dropout):
        super(Encoder_module_v2_rank, self).__init__()

        # target is 6, index is 7
        self.hist_len = hist_len

        # value
        dim_layer_1 = hidden_size + embed_size
        self.linear_1 = nn.Linear(dim_layer_1, hidden_size)
        self.layer_norm = nn.LayerNorm(hidden_size, eps=1e-6)

        self.n_layers = n_layers

        self.hidden_size = hidden_size

        # input dropout
        self.dropout = nn.Dropout(dropout)

        # transformer_encoder
        self.position_enc = PositionalEncoding(hidden_size, n_position=hist_len)
        self.layer_stack = nn.ModuleList([
            EncoderLayer(hidden_size, d_inner, n_head, d_k, d_v, dropout=dropout)
            for _ in range(n_layers)])


    def forward(self, feat_dt, feat_embed):

        xz0 = torch.cat([feat_dt, feat_embed], dim=-1)
        xz1 = F.relu(self.linear_1(xz0))
        enc_output = self.dropout(self.position_enc(xz1))
        enc_output = self.layer_norm(enc_output)

        for enc_layer in self.layer_stack:
            enc_output, _ = enc_layer(enc_output, slf_attn_mask=None)

        return enc_output

    def forward_masked_auxiliary(self, feat_dt, feat_embed, use_trg_mask=True):

        xz0 = torch.cat([feat_dt, feat_embed], dim=-1)
        xz1 = F.relu(self.linear_1(xz0))
        enc_output = self.dropout(self.position_enc(xz1))
        enc_output = self.layer_norm(enc_output)

        trg_mask = None
        if use_trg_mask:
            trg_mask = get_subsequent_mask(feat_dt.size(1), feat_dt.device)

        for enc_layer in self.layer_stack:
            enc_output, _ = enc_layer(enc_output, slf_attn_mask=trg_mask)

        return enc_output


class Encoder_module(nn.Module):
    def __init__(self, feature_dim, embed_dim_total, hidden_size, hist_len, future_len, d_inner, n_layers, n_head, d_k,
                 d_v, dropout):
        super(Encoder_module, self).__init__()

        # target is 6, index is 7
        self.input_size = feature_dim
        # print(self.input_size,'----33')

        self.embed_dim_total = embed_dim_total
        self.hist_len = hist_len

        # value
        self.linear_0 = nn.Linear(self.input_size, hidden_size)

        dim_layer_1 = hidden_size + embed_dim_total
        self.linear_1 = nn.Linear(dim_layer_1, hidden_size)
        self.layer_norm = nn.LayerNorm(hidden_size, eps=1e-6)

        self.n_layers = n_layers

        self.hidden_size = hidden_size

        # input dropout
        self.dropout = nn.Dropout(dropout)

        # transformer_encoder
        self.position_enc = PositionalEncoding(hidden_size, n_position=hist_len)
        self.dropout_2 = nn.Dropout(dropout)
        self.layer_stack = nn.ModuleList([
            EncoderLayer(hidden_size, d_inner, n_head, d_k, d_v, dropout=dropout)
            for _ in range(n_layers)])
        # print(n_layers, '---------------------------')
        # self.layer_norm = nn.LayerNorm(hidden_size, eps=1e-6)

    def init_weights(self):
        """Initialize weights."""
        # init_linear(self.linear_0)
        # init_linear(self.linear_1)
        pass

    def forward(self, dt_feature, feat_embed):
        # form feature
        #print(dt_feature.size(),'---1')
        feat_dt = self.linear_0(dt_feature)  # [B, 5, 7] -> [B, 5, 32]
        # concatenate features
        xz0 = torch.cat([feat_dt, feat_embed], dim=-1)
        xz0 = self.dropout(xz0)
        # xz0 = torch.tanh(xz0)
        # joint and cross fuse features
        xz1 = self.linear_1(xz0)
        xz1 = torch.tanh(xz1)
        # print(xz1.size())

        enc_output = self.dropout_2(self.position_enc(xz1))
        enc_output = self.layer_norm(enc_output)

        for enc_layer in self.layer_stack:
            #enc_output, enc_slf_attn = enc_layer(enc_output, slf_attn_mask=None)
            enc_output, _ = enc_layer(enc_output, slf_attn_mask=None)

        return enc_output


class Encoder_module_v2(nn.Module):
    def __init__(self, feature_dim, embed_dim_total, hidden_size, hist_len, future_len, d_inner, n_layers, n_head, d_k,
                 d_v, dropout):
        super(Encoder_module_v2, self).__init__()

        # target is 6, index is 7
        self.input_size = feature_dim
        self.embed_dim_total = embed_dim_total
        self.hist_len = hist_len

        # value
        self.linear_0 = nn.Linear(self.input_size, hidden_size)

        dim_layer_1 = hidden_size + embed_dim_total
        self.linear_1 = nn.Linear(dim_layer_1, hidden_size)
        self.layer_norm = nn.LayerNorm(hidden_size, eps=1e-6)

        self.n_layers = n_layers

        self.hidden_size = hidden_size

        # input dropout
        self.dropout = nn.Dropout(p=0.5)

        # transformer_encoder
        self.position_enc = PositionalEncoding_v2(hidden_size, max_len=hist_len, dropout=dropout)
        encoder_layers = nn.TransformerEncoderLayer(hidden_size, 8, dim_feedforward=d_inner, dropout=dropout)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layers, n_layers)
        print(n_layers, '---------------------------')
        self.layer_norm = nn.LayerNorm(hidden_size, eps=1e-6)

    def init_weights(self):
        """Initialize weights."""
        init_linear(self.linear_0)
        init_linear(self.linear_1)

    def forward(self, dt_feature, feat_embed):
        # form feature
        feat_dt = self.linear_0(dt_feature)  # [B, 5, 7] -> [B, 5, 32]
        # concatenate features
        xz0 = torch.cat([feat_dt, feat_embed], dim=-1)
        # xz0 = self.dropout(xz0)
        # xz0 = torch.tanh(xz0)
        # joint and cross fuse features
        xz1 = self.linear_1(xz0)
        # xz1 = torch.tanh(xz1)
        # print(xz1.size())
        print('-111')

        xz2 = self.dropout(self.position_enc(xz1))
        src = self.layer_norm(xz2)

        # src = self.position_enc(xz1)
        enc_output = self.transformer_encoder(src, None)
        return enc_output

    def forward_old(self, dt_feature, feat_embed):
        # form feature
        feat_dt = self.linear_0(dt_feature)  # [B, 5, 7] -> [B, 5, 32]
        # concatenate features
        xz0 = torch.cat([feat_dt, feat_embed], dim=-1)
        xz0 = self.dropout(xz0)
        xz0 = torch.tanh(xz0)
        # joint and cross fuse features
        xz1 = self.linear_1(xz0)
        # xz1 = torch.tanh(xz1)
        # print(xz1.size())

        src = self.position_enc(xz1)
        enc_output = self.transformer_encoder(src, None)
        return enc_output
