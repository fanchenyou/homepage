import os
import sys
import time
import torch
from torch import nn
from torch.nn import functional as F

from .embed_module_public import Embed_dynamic_module_v4_with_rank
from .attention_module import MultiHeadAttentionModuleCyclic
from .trans_layer import Decoder_module, Encoder_module_v2_rank


class DTMLNet_Sequence_Quantile_Regression_v5_public(nn.Module):

    def __init__(self, feature_x_dim, feature_ind_dim, stock_vocab_size, num_quantile_pred, exchanger_vocab_size=2,
                 n_classes=3, n_quantiles=11, hidden_size=32, hist_len=5, future_len=1, d_inner=64, trg_pad_idx=None,
                 n_layers=2, n_head=4, d_k=64, d_v=64, dropout=0.2, attention_type=0, enc_dec_type=''):
        super(DTMLNet_Sequence_Quantile_Regression_v5_public, self).__init__()

        self.n_classes = n_classes
        self.n_quantiles = n_quantiles

        self.input_size = feature_x_dim
        self.input_index_size = feature_ind_dim
        self.num_quantile_pred = num_quantile_pred
        self.attention_type = attention_type

        self.n_layers = n_layers
        self.hidden_size = hidden_size
        # TODO, predict future sequence needs this
        self.trg_pad_idx = trg_pad_idx
        assert future_len >= 1
        self.future_len = future_len

        # embedding module
        self.embed_model = Embed_dynamic_module_v4_with_rank(hist_len, stock_vocab_size)
        self.embed_dim_total = self.embed_model.embed_dim_total
        self.embed_dropout = nn.Dropout(dropout)
        self.dt_dropout = nn.Dropout(dropout)

        # encoding module with transformers
        self.linear_input = nn.Linear(self.input_size, hidden_size)  # for rank, and w/o alpha
        self.linear_index = nn.Linear(self.input_index_size, hidden_size)  # for rank, and w/o alpha

        self.input_encoder = Encoder_module_v2_rank(self.embed_dim_total, hidden_size, hist_len, d_inner,
                                                    n_layers, n_head, d_k, d_v, dropout)
        print('Number of enc-dec layers %d' % (n_layers,))

        # attention decoder
        n_head_att = 3
        assert attention_type == 3

        # n_out = 1   # dont use multi-head in dot-attention
        # FIXME, QKV with diff modalities
        self.att_y = MultiHeadAttentionModuleCyclic(n_head_att, hidden_size, hidden_size, hidden_size,
                                                    hidden_size, dropout)
        self.att_ind_0 = MultiHeadAttentionModuleCyclic(n_head_att, hidden_size, hidden_size, hidden_size,
                                                        hidden_size, dropout)
        self.fc_2_y = nn.Linear(hidden_size, hidden_size)  # up, tie, down 3-way classification
        self.fc_2_ind_0 = nn.Linear(hidden_size, hidden_size)

        self.input_decoder = Decoder_module(self.embed_dim_total, hidden_size, hist_len, future_len, d_inner,
                                            n_layers, n_head, d_k, d_v, dropout)

        # value for classification
        self.output_y = nn.Linear(hidden_size, self.n_classes)  # up, tie, down 3-way classification
        self.output_ind_0 = nn.Linear(hidden_size, self.n_classes)

        # quantile prediction
        self.output_y_qt = nn.Linear(hidden_size, self.n_quantiles)  # up, tie, down 3-way classification
        self.output_y_qt_ind_0 = nn.Linear(hidden_size, self.n_quantiles)  # up, tie, down 3-way classification

        # quantile classification
        self.output_c_y_qt = nn.Linear(hidden_size, self.num_quantile_pred * self.num_quantile_pred)

        # cross-sectional stock ranking
        # efficient embedding implementation, to avoid duplicate calculation in calendar and date, time
        # self.embed_model_rank = Embed_dynamic_module_v5_rank(hist_len, stock_vocab_size, exchanger_vocab_size)

        self.init_weights()

    def init_weights(self):
        """Initialize weights."""
        self.embed_model.init_weights()
        self.att_y.init_weights()
        self.att_ind_0.init_weights()
        # self.att_ind_1.init_weights()
        # self.embed_model_rank.init_weights()

    def copy_embedding(self, base_model):
        self.embed_model.copy_embedding(base_model)
        # self.embed_model_rank.copy_embedding(base_model)

    def forward(self, x):
        stock_id, index_id, calendar_id, weekday_id, dt_feature, dt_ind_feat = x
        stock_id[:] = 0  # we don't use stock id
        input_embeds = self.embed_model(stock_id, index_id, calendar_id, weekday_id, future_len=self.future_len)

        feat_dt = self.linear_input(dt_feature)
        feat_dt_index_0 = self.linear_index(dt_ind_feat)

        ft_x = self.input_encoder(feat_dt, input_embeds[0])
        ft_ind_0 = self.input_encoder(feat_dt_index_0, input_embeds[1])

        ot_x = self.att_y(ft_x, ft_ind_0)  # (B, len, n_head * hidden)
        ot_z0 = self.att_ind_0(ft_ind_0, ft_ind_0)

        ot_x_c_2 = F.relu(self.fc_2_y(ot_x))  # (B, len, hidden)
        ot_z0_c_2 = F.relu(self.fc_2_ind_0(ot_z0))

        ft_o_x = self.input_decoder(input_embeds[2], ot_x_c_2)  # [B, future_len, hidden]
        ft_o_ind_0 = self.input_decoder(input_embeds[3], ot_z0_c_2)

        ########## reshape ##########
        ft_o_x = ft_o_x.view(-1, ft_o_x.size(2))
        ft_o_ind_0 = ft_o_ind_0.view(-1, ft_o_ind_0.size(2))

        ########## Classification ############
        y = self.output_y(ft_o_x)  # [B, futrure_len, num_class]
        y_ind_0 = self.output_ind_0(ft_o_ind_0)

        ########## Quantile Classification #######################
        ########## Each quantile classifies to a distribution ####
        ###########  of num_quantile discretized points ##########
        y_qc = self.output_c_y_qt(ft_o_x)
        y_qc = y_qc.view(-1, self.num_quantile_pred, self.num_quantile_pred)

        ########## Classification to diff quantiles ############
        y_qt = y_qc[:, 3, :]  # [B, futrure_len, num_quantile]
        y_qt_ind_0 = self.output_y_qt_ind_0(ft_o_ind_0)  # [B, futrure_len, num_quantile]

        return (y, y_ind_0), (y_qt, y_qt_ind_0), (y_qc)

    def forward_rank(self, x):

        stock_id, index_id, calendar_id, weekday_id, dt_feature, dt_ind_feat = x
        stock_id[:] = 0
        # embed the id inputs, input_embeds[0] is [B, hist_len, d], input_embeds[1] is [1, hist_len,d]
        input_embeds = self.embed_model.forward_rank(stock_id, index_id, calendar_id, weekday_id,
                                                     future_len=self.future_len)

        feat_dt = self.linear_input(dt_feature)  # [N, hist, 32]
        feat_dt_index_0 = self.linear_index(dt_ind_feat)

        # print(feat_dt.size(), input_embeds[0].size(), input_embeds[1].size(),'---0')

        # t1 = time.time()
        ft_x = self.input_encoder(feat_dt, input_embeds[0])
        ft_ind = self.input_encoder(feat_dt_index_0, input_embeds[1])

        # FIXME, Cyclic attention
        ft_ind_2 = ft_ind.repeat(ft_x.size(0), 1, 1)

        ot_x = self.att_y(ft_x, ft_ind_2)  # (B, len, n_head * hidden)
        ot_z0 = self.att_ind_0(ft_ind, ft_ind)

        ot_x_c_2 = F.relu(self.fc_2_y(ot_x))  # (B, len, hidden)
        ot_z0_c_2 = F.relu(self.fc_2_ind_0(ot_z0))

        ft_x = self.input_decoder(input_embeds[2], ot_x_c_2)  # [B, future_len, hidden]
        ft_ind_0 = self.input_decoder(input_embeds[3], ot_z0_c_2)

        ########## reshape ##########
        ft_x = ft_x.view(-1, ft_x.size(2))
        ft_ind_0 = ft_ind_0.view(-1, ft_ind_0.size(2))

        y = self.output_y(ft_x)  # [B, futrure_len, num_class]
        y_ind_0 = self.output_ind_0(ft_ind_0)

        y_qc = self.output_c_y_qt(ft_x)
        y_qc = y_qc.view(-1, self.num_quantile_pred, self.num_quantile_pred)
        y_qt = y_qc[:, 3, :]
        y_qt_ind_0 = self.output_y_qt_ind_0(ft_ind_0)  # [B, futrure_len, num_quantile]

        return (y, y_ind_0), (y_qt, y_qt_ind_0)
