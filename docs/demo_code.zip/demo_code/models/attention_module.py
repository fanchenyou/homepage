import torch
import torch.nn as nn
import torch.nn.functional as F
from .transformer.Modules import ScaledDotProductAttention


class MultiHeadAttentionModuleCyclic(nn.Module):
    """ Multi-Head Attention module """

    def __init__(self, n_head, d_model_qv, d_model_k, d_qv, d_k, dropout=0.1):
        super().__init__()

        self.n_head = n_head
        self.d_k = d_k    # key feature is different from qv
        self.d_qv = d_qv  # query feature is value feature

        self.w_qs = nn.Linear(d_model_qv, n_head * d_k, bias=False)
        self.w_ks = nn.Linear(d_model_k, n_head * d_k, bias=False)
        self.w_vs = nn.Linear(d_model_qv, n_head * d_qv, bias=False)
        self.fc = nn.Linear(n_head * d_qv, d_model_qv, bias=False)

        self.attention = ScaledDotProductAttention(temperature=d_k ** 0.5)
        self.dropout = nn.Dropout(dropout)
        self.layer_norm = nn.LayerNorm(d_model_qv, eps=1e-6)

    def init_weights(self):
        pass

    def forward(self, ft_q, ft_k):

        k = ft_k
        q = v = ft_q
        residual = ft_q

        d_k, d_qv, n_head = self.d_k, self.d_qv, self.n_head
        sz_b, len_q, len_k, len_v = q.size(0), q.size(1), k.size(1), v.size(1)

        # Pass through the pre-attention projection: b x lq x (n*dv)
        # Separate different heads: b x lq x n x dv
        q = self.w_qs(q).view(sz_b, len_q, n_head, d_k)
        k = self.w_ks(k).view(sz_b, len_k, n_head, d_k)
        v = self.w_vs(v).view(sz_b, len_v, n_head, d_qv)

        # print(q.size(), k.size(), v.size())
        # Transpose for attention dot product: b x n x lq x dv
        q, k, v = q.transpose(1, 2), k.transpose(1, 2), v.transpose(1, 2)

        q, attn = self.attention(q, k, v, mask=None)  # (B, n_head, len, hidden)

        q = q.transpose(1, 2).contiguous().view(sz_b, len_q, -1)

        q = self.dropout(self.fc(q))
        q += residual
        q = self.layer_norm(q)

        return q

