import torch
from torch import nn


class Embed_dynamic_module_v4_with_rank(nn.Module):
    def __init__(self, hist_len, stock_vocab_size):
        super(Embed_dynamic_module_v4_with_rank, self).__init__()

        self.stock_embed_dim = 16
        # self.exchanger_embed_dim = 2
        self.date_calendar_embed_dim = 6
        self.weekday_embed_dim = 3
        # self.index_stock_embed_dim = 2
        self.daily_trade_window_dim = 8
        # self.morning_afternoon_embed_dim = 2
        self.hist_len = hist_len
        self.stock_vocab_size = stock_vocab_size
        # embedding
        # to learn index stocks
        # self.index_embed = nn.Embedding(index_vocab_size, self.stock_embed_dim)
        # to learn which stock id, merge with two index stocks
        self.stock_embed = nn.Embedding(stock_vocab_size, self.stock_embed_dim)
        # to learn exchanger in SH or SZ
        # self.exchanger_embed = nn.Embedding(exchanger_vocab_size, self.exchanger_embed_dim)
        # to learn trade in morning (9:30~11:30) or afternoon (1:00~3:00)
        # self.morning_noon_embed = nn.Embedding(2, self.morning_afternoon_embed_dim)
        # to learn which index to use, Husheng300 or Shangzhen500
        # self.index_stock_embed = nn.Embedding(2, self.index_stock_embed_dim)
        # to learn trading time of a day, from 9:30~11:30, 1:00~3:00
        # self.daily_trade_window_embed = nn.Embedding(241, self.daily_trade_window_dim)
        # to learn festivals
        self.date_calendar_embed = nn.Embedding(12 * 31, self.date_calendar_embed_dim)
        # to learn weekday embedding -- Monday -> Friday
        self.weekday_embed = nn.Embedding(7, self.weekday_embed_dim)

        embed_dims = [self.stock_embed_dim, self.date_calendar_embed_dim, self.weekday_embed_dim]
        embed_dim_total = sum(embed_dims)
        self.embed_dim_total = embed_dim_total

        self.index_0_tensor = nn.Parameter(torch.tensor([stock_vocab_size]).long(), requires_grad=False)
        self.index_1_tensor = nn.Parameter(torch.tensor([stock_vocab_size + 1]).long(), requires_grad=False)

    def init_weights(self):
        """Initialize weights."""
        # self.index_embed.weight.data.uniform_(-0.1, 0.1)
        self.stock_embed.weight.data.uniform_(-0.1, 0.1)
        # self.exchanger_embed.weight.data.uniform_(-0.1, 0.1)
        # self.morning_noon_embed.weight.data.uniform_(-0.1, 0.1)
        # self.daily_trade_window_embed.weight.data.uniform_(-0.1, 0.1)
        self.date_calendar_embed.weight.data.uniform_(-0.1, 0.1)
        self.weekday_embed.weight.data.uniform_(-0.1, 0.1)

    def copy_embedding(self, base_model):
        self.stock_embed.weight.data.copy_(base_model['embed_model.stock_embed.weight'])
        self.date_calendar_embed.weight.data.copy_(base_model['embed_model.date_calendar_embed.weight'])
        self.weekday_embed.weight.data.copy_(base_model['embed_model.weekday_embed.weight'])

    def forward(self, stock_id, index_id, calendar_id, weekday_id, future_len=0):

        feat_stock_id = self.stock_embed(stock_id)
        feat_index_id = self.stock_embed(index_id)
        feat_calendar_id = self.date_calendar_embed(calendar_id) # [B, hist, 6]
        feat_weekday_id = self.weekday_embed(weekday_id) # [B, hist, 3]

        invar_embed = torch.cat([feat_calendar_id, feat_weekday_id], dim=-1) # [B, total, 9]
        hist_daily_embed = invar_embed[:, :self.hist_len, :]
        future_daily_embed = invar_embed[:, self.hist_len:, :]

        # [B, dim] => [B, hist, dim]
        feat_embed_1 = feat_stock_id.unsqueeze(1).repeat(1, self.hist_len, 1)
        feat_index_id_1 = feat_index_id.unsqueeze(1).repeat(1, self.hist_len, 1)
        feat_embed_2 = feat_stock_id.unsqueeze(1).repeat(1, future_len, 1)
        feat_index_id_2 = feat_index_id.unsqueeze(1).repeat(1, future_len, 1)

        # [B, hist, 25]
        feat_embed_hist = torch.cat([feat_embed_1, hist_daily_embed], dim=-1)
        index_embed_hist = torch.cat([feat_index_id_1, hist_daily_embed], dim=-1)
        # [B, fut, 25]
        feat_embed_future = torch.cat([feat_embed_2, future_daily_embed], dim=-1)
        index_embed_future = torch.cat([feat_index_id_2, future_daily_embed], dim=-1)

        # print(feat_embed_hist.size(), index_embed_hist.size(),'---1')
        # print(feat_embed_future.size(),index_embed_future.size(),'---2')
        # exit()
        return feat_embed_hist, index_embed_hist, feat_embed_future, index_embed_future

    def forward_rank(self, stock_id, index_id, calendar_id, weekday_id, future_len=0):

        N = stock_id.size(0)
        feat_stock_id = self.stock_embed(stock_id) # [B, 16]
        feat_index_id = self.stock_embed(index_id).unsqueeze(0) # [1, 16]
        feat_calendar_id = self.date_calendar_embed(calendar_id) # [total, 6]
        feat_weekday_id = self.weekday_embed(weekday_id) # [total,3]
        # print(feat_stock_id.size(),feat_index_id.size(), feat_calendar_id.size(), feat_weekday_id.size())

        invar_embed = torch.cat([feat_calendar_id, feat_weekday_id], dim=-1) # [1, total, 9]
        invar_embed = invar_embed.unsqueeze(0)
        hist_daily_embed = invar_embed[:, :self.hist_len, :]
        future_daily_embed = invar_embed[:, self.hist_len:, :]

        feat_embed_1 = feat_stock_id.unsqueeze(1).repeat(1, self.hist_len, 1) # [N, hist, dim]
        feat_index_id_1 = feat_index_id.unsqueeze(1).repeat(1, self.hist_len, 1) # [1, hist, dim]
        feat_embed_2 = feat_stock_id.unsqueeze(1).repeat(1, future_len, 1)  # [N, fut, dim]
        feat_index_id_2 = feat_index_id.unsqueeze(1).repeat(1, future_len, 1) # [1, fut, dim]

        # [N, hist, 25]
        feat_embed_hist = torch.cat([feat_embed_1, hist_daily_embed.repeat(N,1,1)], dim=-1)
        index_embed_hist = torch.cat([feat_index_id_1, hist_daily_embed], dim=-1)
        # [N, fut, 25]
        feat_embed_future = torch.cat([feat_embed_2, future_daily_embed.repeat(N,1,1)], dim=-1)
        index_embed_future = torch.cat([feat_index_id_2, future_daily_embed], dim=-1)

        return feat_embed_hist, index_embed_hist, feat_embed_future, index_embed_future
