import os
import numpy as np
import time
import pickle as pkl

import torch
from torch import nn
from torch.nn import functional as F
from torch.optim.lr_scheduler import MultiStepLR

from losses.loss import l2loss, FocalLoss
from losses.quantile_loss import QuantileClassFocalLoss
from tools.metrics import runningScore, mcc_metric_confusion
from topsort import soft_ot as soft
from quoter_public import Quoter


# for topsort with full Diff-Top-K - in-batch training
# support various attention type for fusing stock modalities
class DTML_Sequence_Quantile_v6_Trainer:
    def __init__(self, args, K_top, feat_dim, num_stock, hist_len, future_len, parameters,
                 trainloader, valloader, testloader, device, steps=1, epochs=50, batch_size=256,
                 attention_type=0, init_model_func=None):

        self.args = args
        self.feat_dim = feat_dim
        self.num_stock = num_stock
        print('stock vocabulary size', self.num_stock)
        self.closing_price_index = 0

        self.trainloader = trainloader
        self.valloader = valloader
        self.testloader = testloader

        self.hist_len = hist_len
        self.future_len = future_len
        self.total_len = hist_len + future_len

        # model parameters
        self.params = parameters
        hidden_size = self.params['unit']
        self.hidden_size = hidden_size
        # training parameters
        self.steps = steps
        self.epochs = epochs
        self.batch_size = batch_size
        self.device = device
        self.adv_eps = self.params['eps']
        self.adv_beta = self.params['bet']
        self.l2_alpha = self.params['alp']
        self.num_layer = args.layer
        self.num_classes = self.params['num_classes']  # binary or triple
        self.val_interval = self.params['val_interval']
        self.save_interval = self.params['save_interval']
        self.save_dir = self.params['save_dir']
        self.train_display_interval = self.params['train_display_interval']
        self.val_display_interval = self.params['val_display_interval']

        self.ce_loss = nn.CrossEntropyLoss()
        self.l2_smooth_loss = nn.SmoothL1Loss()

        self.price_quantile_interval_inverse = 100
        self.quantiles = [5, 10, 15, 20, 25, 30, 50, 70, 75, 80, 85, 90, 95]
        self.quantile_zero_index = 7
        self.num_quantiles = len(self.quantiles) + 2
        self.quantile_captions = ['<5', '5', '10', '15', '20', '25', '30', '36-66', '70', '75', '80', '85', '90', '95',
                                  '95>']

        self.attention_type = attention_type

        self.trainloader_batch = None
        self.K_top = K_top
        self.init_model_func = init_model_func
        self.val_interval = 10

        if 1 == 1:
            # loss function
            self.num_iter = 5
            # self.topK = 1  # TODO, best in target, ind0, ind1 ?
            # self.topL = 1  # TODO, topest? lowest?
            self.epsilon = 3e-2  # larger epsilon lead to smoother relaxation, and requires less num_iter
            self.soft_top1 = soft.TopK_stablized(1, epsilon=self.epsilon, max_iter=self.num_iter, rg=[-5, 5])
            if self.K_top > 0:
                self.soft_topk = soft.TopK_stablized(self.K_top, epsilon=self.epsilon, max_iter=self.num_iter,
                                                     rg=[-5, 5])


# for topsort with full Diff-Top-K - in-batch training
# plus quantile regression
class DTML_Sequence_Quantile_v7_Trainer(DTML_Sequence_Quantile_v6_Trainer):
    def __init__(self, args, K_top, feat_dim, num_stock, hist_len, future_len, parameters,
                 trainloader, valloader, testloader, device, steps=1, epochs=50, batch_size=256,
                 attention_type=0, init_model_func=None, enc_dec_type='simple_enc_dec'):
        super(DTML_Sequence_Quantile_v7_Trainer, self).__init__(args, K_top, feat_dim, num_stock, hist_len, future_len,
                                                                parameters, trainloader, valloader, testloader, device,
                                                                steps=steps, epochs=epochs, batch_size=batch_size,
                                                                attention_type=attention_type,
                                                                init_model_func=init_model_func)

        self.price_quantile_interval = 0.1
        self.price_quantile_interval_inverse = 1.0 / self.price_quantile_interval

        self.quantiles = [15, 25, 35, 50, 65, 75, 85]
        self.quantile_zero_index = 3
        self.num_quantiles = len(self.quantiles)

        quantile_value = [-20, -10, -5, 0, 5.5, 10, 20]  # mid points of quantile_value_seg_points
        quantile_points = np.array([-25, -15, -7.5, 0, 7.5, 15, 25])  # 0.1% - 0.5%

        if args.dset == 'kdd17':
            quantile_captions = ['<17%', '17%', '25%', '40-67%', '75%', '86%', '<86%']
            class_weights = torch.tensor([1.0, 0.7, 0.9]).float().to(device)
            qt_weights = torch.tensor([1, 0.6, 0.55, 0.15, 0.7, 0.5, 0.9]).float().to(device)
            print('Check class weights !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
        else:
            quantile_captions = ['<14%', '14%', '25%', '38-67%', '77%', '88%', '<88%']
            class_weights = torch.tensor([1.0, 1.35, 1.33]).float().to(device)
            qt_weights = torch.tensor([1, 1.02, 1.47, 0.53, 1.29, 1.21, 1.53]).float().to(device)

        self.quantile_captions = quantile_captions
        self.quantile_value = nn.Parameter(torch.FloatTensor(quantile_value), requires_grad=False).to(device)
        self.quantile_value_segs = nn.Parameter(torch.FloatTensor(quantile_points), requires_grad=False).to(device)
        self.num_quantile_pred = len(self.quantiles)

        self.class_ce_loss = FocalLoss(weight=class_weights)
        self.qt_ce_loss = FocalLoss(weight=qt_weights)
        self.QuantileClassLoss = QuantileClassFocalLoss(self.quantiles, self.device, qt_weights)
        self.l2_loss = l2loss()

        self.use_class_and_no_regress = True
        self.enc_dec_type = enc_dec_type

        if args.test or args.backtest:
            self.testloader.dataset.set_price_quantile_interval_inverse(self.price_quantile_interval_inverse)
        else:
            self.trainloader.dataset.set_price_quantile_interval_inverse(self.price_quantile_interval_inverse)
            self.valloader.dataset.set_price_quantile_interval_inverse(self.price_quantile_interval_inverse)

    def init_model(self):
        print('Utilize choice attention type %d' % (self.attention_type,))
        self.model = self.init_model_func(self.feat_dim, self.feat_dim,
                                          num_quantile_pred=self.num_quantile_pred, n_quantiles=self.num_quantiles,
                                          stock_vocab_size=self.num_stock, hidden_size=self.hidden_size,
                                          hist_len=self.hist_len, future_len=self.future_len, n_layers=self.num_layer,
                                          n_classes=self.num_classes, d_inner=self.hidden_size, d_k=self.hidden_size,
                                          d_v=self.hidden_size, attention_type=self.attention_type,
                                          enc_dec_type=self.enc_dec_type).to(self.device)

        if not self.args.test:
            lr = self.params['lr']
            milestones = [30, 60, 120, 200]
            self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr)
            self.scheduler = MultiStepLR(self.optimizer, milestones=milestones, gamma=0.8)
            print(self.optimizer)

    def train(self):
        # load model
        print('Learn DTML_Sequence_Quantile_v7_Trainer with Diff-Top-K -------------')
        train_rank_batch = True
        assert self.K_top > 0

        best_acc = -100
        best_epoch = 0
        all_accs = []

        if train_rank_batch:
            rank_data_iter = iter(self.trainloader_batch)

        # training
        for ep in range(self.epochs):
            print('Epoch %d/%d, lr=%.5f' % (ep, self.epochs, self.optimizer.param_groups[0]['lr']))

            self.model.train()
            if 1 == 1:
                correct_prob = correct_mid_qc = correct_diag_qc = total = 0
                correct_prob_qt = correct_prob_qt_as_lb = 0
                correct_index = 0
                # correct_qt_nz = correct_qc_nz = total_nz = 0
                running_score = runningScore(self.num_classes)
                running_score_qt = runningScore(self.num_quantiles)

                for ix, data in enumerate(self.trainloader):

                    all_inputs = [dt_feat.int().to(self.device) for dt_feat in data[0:4]] + \
                                 [dt_feat.float().to(self.device) for dt_feat in data[4:6]]

                    future_value, future_value_ind = \
                        [x.float().to(self.device, non_blocking=True) for x in data[6:8]]
                    future_label, future_qt_label, future_label_ind, future_qt_label_ind = \
                        [x.long().to(self.device, non_blocking=True) for x in data[8:12]]

                    ###########################################
                    #####             Optimize            #####
                    ###########################################
                    self.optimizer.zero_grad()

                    #######################################
                    # Get inputs from dataloader
                    # input data into model
                    # collect outputs and make GT
                    ########################################
                    if 1 == 1:
                        # print('[trainer_sort] FeatMap size', image_rois.size(), ns)
                        out = self.model(all_inputs)
                        y, y_ind = out[0]
                        y_qt, y_qt_ind = out[1]
                        y_qc = out[2]

                        b_sz = future_value.size(0)
                        b_len = b_sz * self.future_len
                        # assert y.size(0) == b_len

                        # classification
                        # 1. prediction
                        y_l, y_ind_l = y, y_ind
                        y_qt_l, y_qt_ind_l = y_qt, y_qt_ind
                        y_qc_l = y_qc

                        # 2. ground truth
                        # print(future_label.size())
                        w_l = future_label.view(b_len)  # [B*fut_len]
                        w_ind_l = future_label_ind.view(b_len)

                        w_qt_l = future_qt_label.view(b_len)
                        w_qt_ind_l = future_qt_label_ind.view(b_len)

                        # regression as expected quantile value classification
                        zs = []
                        for y0 in [y_qt, y_qt_ind]:
                            prob_qt_y = F.softmax(y0, dim=-1)
                            prob_qt_v = torch.matmul(prob_qt_y, self.quantile_value_segs)
                            prob_qt_v = prob_qt_v.view(b_sz, self.future_len)
                            zs.append(prob_qt_v)
                        z_l, z_ind_l = zs  # [0], future_value_ind_0, future_value_ind_1
                        g_l, g_ind_l = future_value, future_value_ind

                    #############################################
                    ### Classification and Regression Loss   ###
                    #############################################
                    # target stock loss
                    if 2 == 2:
                        loss_class = self.class_ce_loss(y_l, w_l)  # y should be +-1
                        loss_class_ind = self.class_ce_loss(y_ind_l, w_ind_l)

                        loss_qt_0 = self.qt_ce_loss(y_qt_l, w_qt_l)
                        loss_qt_ind = self.qt_ce_loss(y_qt_ind_l, w_qt_ind_l)

                        ###############################################
                        #### quantile regression ###
                        loss_qc = self.QuantileClassLoss(y_qc_l, w_qt_l)
                        ###############################################

                        ###############################################
                        # All classification and regression loss
                        loss_c = 0.2 * (loss_class + 0.2 * loss_class_ind)
                        loss_qt = loss_qt_0 + 0.2 * loss_qt_ind
                        loss_cr = loss_c + loss_qt + loss_qc
                        ###############################################

                    ###############################################
                    # In-Stock stock future timestamps ranking loss
                    ###############################################
                    if 3 == 3:
                        K_top_intra = 1
                        loss_intra_top = torch.tensor(0).float().to(self.device)
                        loss_intra_bot = torch.tensor(0).float().to(self.device)
                        if self.future_len > 1:
                            _, g_sort = torch.topk(g_l, K_top_intra, dim=1)
                            _, g_sort_inv = torch.topk(g_l, K_top_intra, dim=1, largest=False)

                            A_intra = self.soft_top1(-z_l)  # [2,5]
                            A_intra_inv = self.soft_top1(z_l)  # [2,5]

                            A_intra_sort = torch.gather(A_intra, 1, g_sort)
                            A_intra_sort_inv = torch.gather(A_intra_inv, 1, g_sort_inv)

                            loss_intra_top = torch.mean((1 - A_intra_sort) ** 2)
                            loss_intra_bot = torch.mean((1 - A_intra_sort_inv) ** 2)

                    ##############################################
                    # In-Batch target stocks sequence ranking loss
                    ##############################################
                    # FIXME: Check this
                    loss_inter_top = torch.tensor([0]).to(self.device)
                    loss_inter_bot = torch.tensor([0]).to(self.device)
                    global_loss_cr = torch.tensor([0]).to(self.device)
                    global_loss_c = torch.tensor([0]).to(self.device)
                    global_loss_qt = torch.tensor([0]).to(self.device)

                    if 5 == 5 and train_rank_batch:
                        try:
                            rank_inputs = rank_data_iter.next()
                        except StopIteration:
                            rank_data_iter = iter(self.trainloader_batch)
                            rank_inputs = rank_data_iter.next()

                        all_inputs = [dt_feat.squeeze(0).int().to(self.device) for dt_feat in rank_inputs[0:4]] + \
                                     [dt_feat.squeeze(0).float().to(self.device) for dt_feat in rank_inputs[4:6]]

                        # all_inputs = [dt_feat.squeeze(0).to(self.device) for dt_feat in rank_inputs[0:9]]
                        future_label, future_qt_label, future_label_ind, future_qt_label_ind, g_sort, g_sort_inv = [
                            x.squeeze(0).long().to(self.device, non_blocking=True) for x in rank_inputs[6:12]]

                        # input -> model -> output
                        out = self.model.forward_rank(all_inputs)
                        p, p_ind = out[0]
                        p_qt, p_qt_ind_0 = out[1]

                        r_sz = future_qt_label.size(0)
                        r_len = r_sz * self.future_len
                        r_ind_len = self.future_len

                        ######################################################
                        # Global rank - cross-sectional ranking loss #
                        # find top/bot 25 stocks to choose to invest or sell #
                        ######################################################
                        if 1 == 1:
                            p_qt_l = p_qt.view(r_sz, self.future_len, p_qt.size(-1))
                            prob_qt_y = F.softmax(p_qt_l, dim=-1)
                            prob_qt_v = torch.matmul(prob_qt_y, self.quantile_value_segs)
                            # print(prob_qt_v.size())
                            z_all = prob_qt_v.t()

                            A_inter = self.soft_topk(-z_all)  # [B=708,5], largest one should be top, so take reverse
                            A_inter_inv = self.soft_topk(z_all)  # lowest one should be top
                            A_inter_sort = torch.gather(A_inter.t(), 0, g_sort)
                            A_inter_sort_inv = torch.gather(A_inter_inv.t(), 0, g_sort_inv)

                            loss_inter_top = torch.mean((1 - A_inter_sort) ** 2)
                            loss_inter_bot = torch.mean((1 - A_inter_sort_inv) ** 2)

                    l2_loss = self.l2_alpha * self.l2_loss(self.model)

                    loss_rank = 0.5 * (loss_intra_top + loss_intra_bot) + \
                                0.5 * (loss_inter_top + loss_inter_bot)

                    loss = loss_cr + 0.3 * loss_rank + l2_loss

                    loss.backward()
                    self.optimizer.step()

                    if ix % 100 == 0:
                        # evaluate
                        pred = y_l.argmax(dim=1, keepdim=False)  # get the index of the max log-probability
                        correct_prob += pred.eq(w_l).sum().item()

                        pred_qt = y_qt_l.argmax(dim=1, keepdim=False)  # get the index of the max log-probability
                        correct_prob_qt += pred_qt.eq(w_qt_l).sum().item()

                        y_qc_mid_l = y_qc_l[:, self.quantile_zero_index, :]
                        pred_qc = y_qc_mid_l.argmax(dim=1, keepdim=False)
                        correct_mid_qc += pred_qc.eq(w_qt_l).sum().item()

                        pred_ind = y_ind_l.argmax(dim=1, keepdim=False)
                        correct_index += pred_ind.eq(w_ind_l).sum().item()

                        total += pred.size(0)

                        running_score.update(pred, w_l)
                        running_score_qt.update(pred_qt, w_qt_l)

                    if ix % self.train_display_interval == 0:

                        print('  [Train] %d/%d, loss %.3f' % (ix, len(self.trainloader), loss.item()))
                        print('   [*] loss %.3f <- loss_cr %.3f, global_loss_cr %.3f, loss_rank %.3f, l2_loss %.3f' % (
                            loss.item(), loss_cr.item(), global_loss_cr.item(), loss_rank.item(), l2_loss.item()))
                        print('    + loss_cr %.3f <- loss_c %.3f, loss_qt %.3f, loss qc %.3f' % (
                            loss_cr.item(), loss_c.item(), loss_qt.item(), loss_qc.item()))
                        print('    + loss_c %.3f <- loss_0 %.3f, loss_ind %.3f' % (
                            loss_c.item(), loss_class.item(), loss_class_ind.item()))
                        print('    + loss_qt %.3f <- loss_q_0 %.3f, loss_q_ind %.3f' % (
                            loss_qt.item(), loss_qt_0.item(), loss_qt_ind.item()))
                        # print('    = Non-zero accuracy qt %.3f, qc %.3f' % (
                        #     correct_qt_nz / total_nz, correct_qc_nz / total_nz))
                        print('    = acc/qt %.3f, [qt %.3f, qc %.3f], ind %.3f' % (
                            correct_prob / total, correct_prob_qt / total,
                            correct_mid_qc / total, correct_index / total))

                        if ix > 0 and ix % (4 * self.train_display_interval) == 0:
                            running_score.normalize()
                            running_score.print_score_norm_round()
                            running_score_qt.normalize()
                            running_score_qt.print_score_norm_int()
                            print('dist', np.round(running_score.class_hist / running_score.class_hist[0], 2))
                            print('inv dist', np.round(running_score.class_hist[0] / running_score.class_hist, 2))
                            print('dist', np.round(running_score_qt.class_hist / running_score_qt.class_hist[0], 2))
                            print('inv dist', np.round(running_score_qt.class_hist[0] / running_score_qt.class_hist, 2))

            self.scheduler.step()

            if ep > 0 and ep % self.val_interval == 0:
                self.model.eval()
                # check overall accuracy
                correct_prob = total = 0
                correct_prob_qt = correct_prob_qt_as_lb = 0
                correct_index = correct_ind_qt = total_index = 0
                # check every position in future len
                correct_positions = torch.zeros(self.future_len).to(self.device)
                correct_qt_positions = torch.zeros(self.future_len).to(self.device)
                total_position_sample = 0
                correct_mid_qc = correct_diag_qc = 0
                correct_qt_nz = correct_qc_nz = total_nz = 0

                running_score = runningScore(self.num_classes)
                running_score_qt = runningScore(self.num_quantiles)
                running_score_ind_qt = runningScore(self.num_quantiles)

                with torch.no_grad():
                    for j, data in enumerate(self.valloader):
                        ########################
                        # get all hist features
                        ########################
                        all_inputs = [dt_feat.int().to(self.device) for dt_feat in data[0:4]] + \
                                     [dt_feat.float().to(self.device) for dt_feat in data[4:6]]

                        # future_value, future_value_ind = \
                        #     [x.float().to(self.device, non_blocking=True) for x in data[6:8]]
                        future_label, future_qt_label, future_label_ind, future_qt_label_ind = \
                            [x.long().to(self.device, non_blocking=True) for x in data[8:12]]

                        ###########################################
                        #####            Evaluate             #####
                        ###########################################
                        out = self.model(all_inputs)
                        y, y_ind = out[0]
                        y_qt, y_qt_ind = out[1]
                        y_qc = out[2]

                        b_sz = future_label.size(0)
                        b_len = b_sz * self.future_len

                        y_l, y_ind_l = y, y_ind
                        y_qt_l, y_qt_ind_l = y_qt, y_qt_ind
                        y_qc_l = y_qc

                        # 2. GT
                        w_l = future_label.view(b_len)  # [B*fut_len]
                        w_ind_l = future_label_ind.view(b_len)
                        w_qt_l = future_qt_label.view(b_len)
                        w_qt_ind_l = future_qt_label_ind.view(b_len)

                        pred = y_l.argmax(dim=1, keepdim=False)  # get the index of the max log-probability
                        correct_prob += pred.eq(w_l).sum().item()

                        pred_qt = y_qt_l.argmax(dim=1, keepdim=False)  # get the index of the max log-probability
                        correct_prob_qt += pred_qt.eq(w_qt_l).sum().item()

                        y_pos = y.view(b_sz, self.future_len, y.size(-1))
                        pred_pos = y_pos.argmax(dim=2, keepdim=False)  # (B, fut_len)
                        correct_positions += pred_pos.eq(future_label).sum(dim=0)
                        total_position_sample += b_sz

                        y_qt_pos = y_qt.view(b_sz, self.future_len, y_qt.size(-1))
                        pred_qt_pos = y_qt_pos.argmax(dim=2, keepdim=False)
                        correct_qt_positions += pred_qt_pos.eq(future_qt_label).sum(dim=0)

                        pred_qt_cls = torch.zeros_like(pred_qt).to(self.device)
                        # print(future_label.size(),pred_qt.size(),'==')
                        pred_qt_cls[pred_qt == self.quantile_zero_index] = 1
                        pred_qt_cls[pred_qt < self.quantile_zero_index] = 0
                        pred_qt_cls[pred_qt > self.quantile_zero_index] = 2
                        correct_prob_qt_as_lb += pred_qt_cls.eq(w_l).sum().item()

                        y_qc_mid_l = y_qc_l[:, self.quantile_zero_index, :]
                        pred_qc = y_qc_mid_l.argmax(dim=1, keepdim=False)
                        correct_mid_qc += pred_qc.eq(w_qt_l).sum().item()
                        # assert pred_qc.size(0) == pred.size(0)

                        y_qc_diag = torch.diagonal(y_qc_l, dim1=1, dim2=2)  # [-1, 7]
                        pred_diag_qc = y_qc_diag.argmax(dim=1, keepdim=False)
                        correct_diag_qc += pred_diag_qc.eq(w_qt_l).sum().item()
                        # assert pred_qc.size(0) == pred.size(0)

                        running_score.update(pred, w_l)
                        running_score_qt.update(pred_qt, w_qt_l)

                        ######### non-zero performance  ##########
                        non_zero_indices = (w_qt_l != self.quantile_zero_index)
                        gt_qt_nz = w_qt_l[non_zero_indices]
                        pred_qt_nz = pred_qt[non_zero_indices]
                        pred_qc_nz = pred_qc[non_zero_indices]
                        correct_qt_nz += pred_qt_nz.eq(gt_qt_nz).sum().item()
                        correct_qc_nz += pred_qc_nz.eq(gt_qt_nz).sum().item()
                        total_nz += gt_qt_nz.size(0)

                        if j <= 100:
                            pred_ind = y_ind_l.argmax(dim=1, keepdim=False)
                            cur_correct_ind = pred_ind.eq(w_ind_l).sum().item()
                            correct_index += cur_correct_ind
                            total_index += pred_ind.size(0)

                            pred_ind_qt = y_qt_ind_l.argmax(dim=1, keepdim=False)
                            correct_ind_qt += pred_ind_qt.eq(w_qt_ind_l).sum().item()
                            running_score_ind_qt.update(pred_ind_qt, w_qt_ind_l)

                        total += pred.size(0)

                        if j >= 0 and j % self.val_display_interval == 0:
                            print(
                                '  Evaluate %d/%d, bsize %d, val/qt acc %.3f/%.3f, [qt acc %.3f, qc acc %.3f, qc diag %.3f], ind acc/qt %.3f/%.3f'
                                % (j, len(self.valloader), pred.size(0), correct_prob / total,
                                   correct_prob_qt_as_lb / total, correct_prob_qt / total, correct_mid_qc / total,
                                   correct_diag_qc / total, correct_index / total_index, correct_ind_qt / total_index))
                            # print('  Average time ----->', time_acc.item())
                            print('  Positional accuracy from 1-%d' % (self.future_len,),
                                  correct_positions / total_position_sample)
                            print('  Positional QT accuracy from 1-%d' % (self.future_len,),
                                  correct_qt_positions / total_position_sample)
                            mean_acc, mean_accs = running_score_qt.get_per_class_acc()
                            print('  Per-class accuracy %.3f' % (mean_acc,), np.round(mean_accs, 3))
                            print('  Non-zero accuracy qt %.3f, qc %.3f' % (
                                correct_qt_nz / total_nz, correct_qc_nz / total_nz))

                            # statitics of quantile classification
                            # print('----------------')
                            # print(w_qt_l[:20], '----gt')
                            # print(pred_qt[:20], '----qt')
                            # print(pred_qc[:20], '---qc')
                            # print(pred_diag_qc[:20], '---qc_diag')
                            # for t in range(self.num_quantiles):
                            #     tmp = y_qc_l[:20, t, :]
                            #     tmp2 = tmp.argmax(dim=1, keepdim=False)
                            #     print(t, tmp2)
                            # print('-----------------------')

                # print('Average time ----->', time_acc.item())
                self.model.train()

                acc = correct_prob / total
                acc_qt = correct_prob_qt / total
                acc_qt_lb = correct_prob_qt_as_lb / total
                acc_qc = correct_mid_qc / total
                acc_qc_diag = correct_diag_qc / total
                print('  [Evaluate] Epoch %d/%d: val/qt acc %.3f/%.3f, [qt acc %.3f, qc acc %.3f], qc diag %.3f' %
                      (ep, self.epochs, acc, acc_qt_lb, acc_qt, acc_qc, acc_qc_diag))

                acc_positions = correct_positions / total_position_sample
                acc_positions = acc_positions.cpu().numpy().tolist()
                print('  Positional accuracy from 1-%d' % (self.future_len,), acc_positions)

                acc_qt_positions = correct_qt_positions / total_position_sample
                acc_qt_positions = acc_qt_positions.cpu().numpy().tolist()
                print('  Positional QT accuracy from 1-%d' % (self.future_len,), acc_qt_positions)

                mean_acc, mean_accs = running_score_qt.get_per_class_acc()
                print('  Per-class accuracy %.3f' % (mean_acc,), np.round(mean_accs, 3))
                print('  Non-zero accuracy qt %.3f, qc %.3f' % (correct_qt_nz / total_nz, correct_qc_nz / total_nz))

                running_score.normalize()
                running_score.print_score_norm_round()
                running_score_qt.normalize()
                running_score_qt.print_score_norm_int()

                print('---ind')
                running_score_ind_qt.normalize()
                running_score_ind_qt.print_score_norm_int()
                print()

                print('Data stats')
                print('-------------------')
                print(running_score.class_hist)
                print(running_score.confusion_matrix.sum(0))
                print('dist', np.round(running_score.class_hist / running_score.class_hist[0], 2))
                print('inv dist', np.round(running_score.class_hist[0] / running_score.class_hist, 2))

                print('-------------------')
                print(running_score_qt.class_hist)
                print(running_score_qt.confusion_matrix.sum(0))
                print('dist', np.round(running_score_qt.class_hist / running_score_qt.class_hist[0], 2))
                print('inv dist', np.round(running_score_qt.class_hist[0] / running_score_qt.class_hist, 2))

                acc_res = 'Acc_%.3f_AccQt_%.3f_AccQc_%.3f' % (acc, acc_qt, acc_qc)
                all_accs.append(acc_res)
                print(all_accs)

                # creteria choosen
                creteria_acc = acc_qt  # acc

                found_best = False
                if creteria_acc > best_acc:
                    best_acc = creteria_acc
                    best_epoch = ep
                    found_best = True

                # found best
                if found_best:
                    state = {
                        "best_epoch": best_epoch,
                        "best_acc": best_acc,
                        "model_state": self.model.state_dict(),
                    }
                    save_path = os.path.join(self.save_dir, "best_model.pth")
                    torch.save(state, save_path)
                    print(' *** [BEST] Found best epoch %d, acc %.3f' % (best_epoch, best_acc))
                    print('Best model save to %s' % (self.save_dir,))

                else:
                    print(' Prev best epoch %d, acc %.3f' % (best_epoch, best_acc))
                    print(' model path %s' % (self.save_dir,))

            if ep > 0 and ep % self.save_interval == 0:
                state = {
                    "epoch": ep,
                    "this_acc": creteria_acc,
                    "best_epoch": best_epoch,
                    "best_acc": best_acc,
                    "model_state": self.model.state_dict(),
                }
                save_path = os.path.join(self.save_dir, "model_%d.pth" % (ep,))
                torch.save(state, save_path)
                print('Save to %s  %s' % (self.save_dir, "model_%d.pth" % (ep,)))
                print()

    def evaluate(self, loader=None):

        if loader is None:
            loader = self.testloader
            assert loader is not None

        self.model.eval()

        # add confusion matrix
        running_score = runningScore(self.num_classes)
        running_score_qt = runningScore(self.num_quantiles)
        running_score_big_qt = runningScore(self.num_quantiles)
        running_score_ind_qt = runningScore(self.num_quantiles)
        move_confusion_matrix = np.zeros((2, 2))

        # check overal accuracy
        correct_prob = total = 0
        correct_prob_qt = correct_prob_qt_as_lb = 0
        correct_big_qt = total_big_qt = 0
        correct_big_qt_binary = 0
        correct_index = correct_ind_qt = total_index = 0

        # check every position in future len
        correct_positions = torch.zeros(self.future_len).to(self.device)
        correct_qt_positions = torch.zeros(self.future_len).to(self.device)
        total_position_sample = 0
        correct_mid_qc = correct_diag_qc = 0
        correct_qt_nz = correct_qc_nz = total_nz = 0
        correct_move = correct_move_qt = total_move = 0

        with torch.no_grad():
            for j, data in enumerate(self.testloader):
                all_inputs = [dt_feat.int().to(self.device) for dt_feat in data[0:4]] + \
                             [dt_feat.float().to(self.device) for dt_feat in data[4:6]]

                # future_value, future_value_ind = \
                #     [x.float().to(self.device, non_blocking=True) for x in data[6:8]]
                future_label, future_qt_label, future_label_ind, future_qt_label_ind = \
                    [x.long().to(self.device, non_blocking=True) for x in data[8:12]]

                ###########################################
                #####            Evaluate             #####
                ###########################################
                # print('[trainer_sort] FeatMap size', image_rois.size(), ns)
                # y, y_qt, y_ind_0, y_ind_1, z, z_ind_0, z_ind_1 = self.model(all_inputs)[:7]
                out = self.model(all_inputs)
                y, y_ind = out[0]
                y_qt, y_qt_ind = out[1]
                y_qc = out[2]

                b_sz = future_label.size(0)
                b_len = b_sz * self.future_len
                # print(y.size())

                if 1 == 1:
                    y_l, y_ind_l = y, y_ind
                    y_qt_l, y_qt_ind_l = y_qt, y_qt_ind
                    y_qc_l = y_qc

                    # 2. GT
                    w_l = future_label.view(b_len)  # [B*fut_len]
                    w_ind_l = future_label_ind.view(b_len)
                    w_qt_l = future_qt_label.view(b_len)
                    w_qt_ind_l = future_qt_label_ind.view(b_len)

                    pred = y_l.argmax(dim=1, keepdim=False)  # get the index of the max log-probability
                    correct_prob += pred.eq(w_l).sum().item()

                    # to evaluate quantile regression
                    pred_qt = y_qt_l.argmax(dim=1, keepdim=False)  # get the index of the max log-probability
                    correct_prob_qt += pred_qt.eq(w_qt_l).sum().item()

                    # positional accuracy
                    y_pos = y.view(b_sz, self.future_len, y.size(-1))
                    pred_pos = y_pos.argmax(dim=2, keepdim=False)  # (B, fut_len)
                    correct_positions += pred_pos.eq(future_label).sum(dim=0)
                    total_position_sample += b_sz

                    y_qt_pos = y_qt.view(b_sz, self.future_len, y_qt.size(-1))
                    pred_qt_pos = y_qt_pos.argmax(dim=2, keepdim=False)
                    correct_qt_positions += pred_qt_pos.eq(future_qt_label).sum(dim=0)

                    # to evaluate as binary classification
                    pred_qt_cls = torch.zeros_like(pred_qt).to(self.device)
                    pred_qt_cls[pred_qt == self.quantile_zero_index] = 1
                    pred_qt_cls[pred_qt < self.quantile_zero_index] = 0
                    pred_qt_cls[pred_qt > self.quantile_zero_index] = 2
                    correct_prob_qt_as_lb += pred_qt_cls.eq(w_l).sum().item()

                    ##################################
                    ### up/down movement prediction ##
                    ##################################
                    w_move = (w_l != 1)
                    if w_move.size(0) > 0:
                        # print(w_l, w_l[w_move])
                        pred_move = pred[w_move]  # get the index of the max log-probability
                        correct_move += pred_move.eq(w_l[w_move]).sum().item()
                        total_move += pred_move.size(0)
                        correct_move_qt += pred_qt_cls[w_move].eq(w_l[w_move]).sum().item()

                        gt_move = w_l[w_move]
                        # for w in gt_move:
                        #     assert w==0 or w==2
                        # true negative
                        ind_neg = (gt_move == 0)
                        ind_pos = (gt_move == 2)

                        true_neg_ind = (pred_move[ind_neg] == 0)
                        true_pos_ind = (pred_move[ind_pos] == 2)
                        false_neg_ind = (pred_move[ind_pos] < 2)
                        false_pos_ind = (pred_move[ind_neg] > 0)

                        tn = pred_move[ind_neg][true_neg_ind].size(0)
                        tp = pred_move[ind_pos][true_pos_ind].size(0)
                        fn = pred_move[ind_pos][false_neg_ind].size(0)
                        fp = pred_move[ind_neg][false_pos_ind].size(0)
                        # print(tn, tp, fn, fp, gt_move.size())

                        move_confusion_matrix[0, 0] += tn
                        move_confusion_matrix[1, 1] += tp
                        move_confusion_matrix[0, 1] += fp
                        move_confusion_matrix[1, 0] += fn

                        # print(mcc_metric_confusion(move_confusion_matrix))

                    y_qc_mid_l = y_qc_l[:, self.quantile_zero_index, :]
                    pred_qc = y_qc_mid_l.argmax(dim=1, keepdim=False)
                    correct_mid_qc += pred_qc.eq(w_qt_l).sum().item()
                    assert pred_qc.size(0) == pred.size(0)

                    y_qc_diag = torch.diagonal(y_qc_l, dim1=1, dim2=2)  # [-1, 7]
                    pred_diag_qc = y_qc_diag.argmax(dim=1, keepdim=False)
                    correct_diag_qc += pred_diag_qc.eq(w_qt_l).sum().item()

                    running_score.update(pred, w_l)
                    running_score_qt.update(pred_qt, w_qt_l)

                    ######### non-zero performance  ##########
                    non_zero_indices = (w_qt_l != self.quantile_zero_index)
                    gt_qt_nz = w_qt_l[non_zero_indices]
                    pred_qt_nz = pred_qt[non_zero_indices]
                    pred_qc_nz = pred_qc[non_zero_indices]
                    correct_qt_nz += pred_qt_nz.eq(gt_qt_nz).sum().item()
                    correct_qc_nz += pred_qc_nz.eq(gt_qt_nz).sum().item()
                    total_nz += gt_qt_nz.size(0)

                    total += pred.size(0)

                    # to evaluate in going up or down by more than 20%> stocks
                    big_qt_ind = (w_qt_l > self.quantile_zero_index + 1) | (w_qt_l < self.quantile_zero_index - 1)

                    w_big_qt_l = w_qt_l[big_qt_ind]
                    if w_big_qt_l.size(0) > 0:
                        pred_big_qt = pred_qt[big_qt_ind]
                        correct_big_qt += pred_big_qt.eq(w_big_qt_l).sum().item()
                        total_big_qt += w_big_qt_l.size(0)
                        running_score_big_qt.update(pred_big_qt, w_big_qt_l)

                        pred_big_binary = pred[big_qt_ind]
                        w_big_qt_binary = w_l[big_qt_ind]
                        # print(w_big_qt_binary)
                        t_0 = w_big_qt_binary == 1
                        # if t_0.any():
                        #     print(w_big_qt_binary,  future_value[0,:,0][big_qt_ind])
                        assert not t_0.any()
                        # print(pred_big_binary.size(), w_big_qt_binary.size())
                        correct_big_qt_binary += pred_big_binary.eq(w_big_qt_binary).sum().item()
                        # print(w_big_qt_binary)

                # to evaluate on index stocks
                if j <= 100:
                    pred_ind = y_ind_l.argmax(dim=1, keepdim=False)
                    cur_correct_ind = pred_ind.eq(w_ind_l).sum().item()
                    correct_index += cur_correct_ind
                    total_index += pred_ind.size(0)

                    pred_ind_qt = y_qt_ind_l.argmax(dim=1, keepdim=False)
                    correct_ind_qt += pred_ind_qt.eq(w_qt_ind_l).sum().item()
                    running_score_ind_qt.update(pred_ind_qt, w_qt_ind_l)

                if j > 0 and j % 10 == 0:
                    # print('Miss rate %.3f' % (cnt_miss / cnt_all))
                    print('  Test %d/%d, bsize %d, test acc/qt %.3f/%.3f, ind acc/qt %.3f/%.3f, '
                          '[2-class move acc/qt %.3f/%.3f] [qt acc %.3f, qc acc %.3f qc diag %.3f], mcc %.3f' %
                          (j, len(self.testloader), pred.size(0), correct_prob / total, correct_prob_qt_as_lb / total,
                           correct_index / total_index, correct_ind_qt / total_index,
                           correct_move / total_move, correct_move_qt / total_move,
                           correct_prob_qt / total, correct_mid_qc / total, correct_diag_qc / total,
                           mcc_metric_confusion(move_confusion_matrix)))
                    print('  Positional accuracy from 1-%d' % (self.future_len,),
                          correct_positions / total_position_sample)
                    print('  Positional QT accuracy from 1-%d' % (self.future_len,),
                          correct_qt_positions / total_position_sample)

                    mean_acc, mean_accs = running_score_qt.get_per_class_acc()
                    print('  Per-class accuracy %.3f' % (mean_acc,), mean_accs)
                    print('  Non-zero accuracy qt %.3f, qc %.3f' % (correct_qt_nz / total_nz, correct_qc_nz / total_nz))

        acc = correct_prob / total
        acc_prob_qt_as_lb = correct_prob_qt_as_lb / total
        acc_qt = correct_prob_qt / total
        acc_ind, acc_ind_qt = correct_index / total_index, correct_ind_qt / total_index
        acc_big_qt = correct_big_qt / total_big_qt
        acc_big_qt_binary = correct_big_qt_binary / total_big_qt
        acc_qc = correct_mid_qc / total
        acc_qc_diag = correct_diag_qc / total
        mcc = mcc_metric_confusion(move_confusion_matrix)
        print()
        print('[TEST] test D-Acc %.3f Q-Acc %.3f, Per-class %.3f mcc %.3f' % (acc, acc_qt, mean_acc, mcc))
        mean_acc, mean_accs = running_score_qt.get_per_class_acc()
        print('  Per-class accuracy %.3f' % (mean_acc,), mean_accs)

        print('%.4f & %.4f & %.4f & %.4f' % (acc, acc_qt, mean_acc, mcc))

        running_score.normalize()
        running_score.print_score_norm_round()
        running_score_qt.normalize()
        running_score_qt.print_score_norm_int()
        print()

        print('---ind')
        running_score_ind_qt.normalize()
        running_score_ind_qt.print_score_norm_int()
        print()

        print('Data stats')
        print('-------------------')
        print(running_score.class_hist)
        print(running_score.confusion_matrix.sum(0))
        print('dist', running_score.class_hist / running_score.class_hist[0])
        print('inv dist', running_score.class_hist[0] / running_score.class_hist)

        print('-------------------')
        print(running_score_qt.class_hist)
        print(running_score_qt.confusion_matrix.sum(0))
        print('dist', running_score_qt.class_hist / running_score_qt.class_hist[0])
        print('inv dist', running_score_qt.class_hist[0] / running_score_qt.class_hist)

        self.model.train()

    def backtest(self):

        self.model.eval()

        quoter = Quoter()
        fname = os.path.join(self.args.model_dir, 'backtest_result.pkl')

        if os.path.isfile(fname):
            with open(fname, 'rb') as f:
                all_data = pkl.load(f)
            print(len(all_data))
            all_data_segs = []

            for key in list(all_data.keys()):
                all_data_key = all_data[key]
                st = 0
                while True:
                    # one-month rate
                    end_id = st + 30
                    if end_id >= len(all_data_key[0]):
                        break

                    t1 = np.array(all_data_key[0][st:end_id])
                    t2 = np.array(all_data_key[1][st:end_id])
                    t3 = np.array(all_data_key[2][st:end_id])
                    # print(t1.shape, t1)

                    all_data_segs.append([t1, t2, t3])
                    st = end_id

            vols = [1, 5, 10]
            pnl_free, pnl_free_qt = np.zeros(len(vols)), np.zeros(len(vols))
            # retractions_1, retractions_2, retractions_2_2 = [], [], []

            tt = 0
            for mkt_price, y_move_t, y_move_qt in all_data_segs:
                # print(mkt_price.shape, y_move_t.shape, y_move_qt.shape)
                tt += 1
                for ix, vol in enumerate(vols):
                    pnl = quoter.get_trade_pnl_from_movement_prediction_volume(mkt_price, y_move_t, vol)
                    pnl_free[ix] += pnl

                for ix, vol in enumerate(vols):
                    pnl = quoter.get_trade_pnl_from_movement_prediction_quantile_volume(mkt_price, y_move_qt, vol)
                    pnl_free_qt[ix] += pnl

            t1 = np.round(pnl_free / tt / 30 * 365, 5)
            t2 = np.round(pnl_free_qt / tt / 30 * 365, 5)
            t1 = [str(j) for j in t1]
            t2 = [str(j) for j in t2]

            t1_str = ' & '.join(t1)
            t2_str = ' & '.join(t2)

            print(t1_str, ' ', t2_str)

        else:
            all_data = {}
            with torch.no_grad():
                for j, data in enumerate(self.testloader):
                    if j % 100 == 0:
                        print('%d/%d' % (j, len(self.testloader)))
                    # if j>100:
                    #     break
                    all_inputs = [dt_feat.int().to(self.device) for dt_feat in data[0:4]] + \
                                 [dt_feat.float().to(self.device) for dt_feat in data[4:6]]
                    future_value = data[6].float().to(self.device)
                    future_label, future_qt_label, future_label_ind, future_qt_label_ind = \
                        [x.long().to(self.device, non_blocking=True) for x in data[8:12]]

                    ###########################################
                    #####            Evaluate             #####
                    ###########################################
                    stock_id = data[0].item()
                    if stock_id not in all_data:
                        all_data[stock_id] = [[], [], []]

                    # print('[trainer_sort] FeatMap size', image_rois.size(), ns)
                    # y, y_qt, y_ind_0, y_ind_1, z, z_ind_0, z_ind_1 = self.model(all_inputs)[:7]
                    out = self.model(all_inputs)
                    y, y_ind = out[0]
                    y_qt, y_qt_ind = out[1]
                    # y_qc = out[2]

                    b_sz = future_label.size(0)
                    # b_len = b_sz * self.future_len

                    # future value
                    mkt_price = future_value[:, 0].item() / self.price_quantile_interval_inverse
                    # print(mkt_price)

                    y_move = y.view(b_sz, self.future_len, y.size(-1))
                    pred = y_move[:, 0, :].argmax(dim=1, keepdim=False)
                    y_move_t_np = pred.item()

                    y_move_qt = y_qt.view(b_sz, self.future_len, y_qt.size(-1))
                    pred_qt = y_move_qt[:, 0, :].argmax(dim=1,
                                                        keepdim=False)  # get the index of the max log-probability
                    # print(pred_qt)
                    y_move_qt_np = pred_qt.item()

                    all_data[stock_id][0].append(mkt_price)
                    all_data[stock_id][1].append(y_move_t_np)
                    all_data[stock_id][2].append(y_move_qt_np)

                    # print(all_data[stock_id][0])

            with open(fname, 'wb') as f:
                pkl.dump(all_data, f)

            print('Write data file to %s' % (fname,))
            print('Check the data file, and execute the same cmd again !!!!')
