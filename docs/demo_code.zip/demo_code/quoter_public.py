import os
import numpy as np


class Quoter:
    def __init__(self, fee: float = 1e-3, vol: int = 100):
        self.fee = fee
        self.vol = vol

    def get_trade_pnl_from_movement_prediction(self, gain_ratios, pred_move):
        num_points = len(gain_ratios)
        assert len(pred_move) == num_points
        if num_points < 2:
            return 0
        cum = 0
        volumes = []
        cur_volume = 0
        #price_changes = mkt_prices[1:]

        price_changes = gain_ratios[1:]/100  # should be equal to mkt_price[1:]-mkt_price[0:]

        for i in range(0, num_points - 1):
            if pred_move[i] == 2:
                # print(mkt_prices[i])
                # cum += (mkt_prices[i] - mkt_prices[i - 1]*(1+self.fee))/ mkt_prices[i-1]
                if cur_volume == 0:
                    cur_volume = 1
            elif pred_move[i] == 0:
                # price go down, sell itdt_feature
                if cur_volume == 1:
                    cur_volume = 0
            else:
                # no price change
                pass
            volumes.append(cur_volume)

        volumes = np.array(volumes)
        total_trade = np.sum(np.max(volumes[1:-1] - volumes[:-2],0)) + volumes[-1]
        fee_all = 5e-3 * total_trade
        fee_all = 0

        gain_total = np.array(price_changes) * np.array(volumes)
        gain_all = np.sum(gain_total) - fee_all

        print(gain_ratios)
        print(pred_move)
        print(volumes)
        print(gain_all)
        print()

        ####################
        ## max retraction ##
        ####################
        # max_retract = 0.0
        # value_total = mkt_prices[1:] * np.array(volumes) / mkt_prices[1]
        # for i in range(0, num_points-2):
        #     t_m = np.min(value_total[i+1:]) - value_total[i]
        #     max_retract = np.min([t_m, max_retract])
        #
        # #print(gain_all, gain_all)
        # return gain_all, max_retract
        return gain_all

    def get_trade_pnl_from_movement_prediction_volume(self, gain_ratios, pred_move, max_volume=5):
        num_points = len(gain_ratios)
        assert len(pred_move) == num_points
        if num_points < 2:
            return 0

        volumes = []
        cur_volume = 0
        #price_changes = mkt_prices[1:]

        price_changes = gain_ratios[1:]/100  # should be equal to mkt_price[1:]-mkt_price[0:]

        for i in range(0, num_points - 1):
            if pred_move[i] == 2:
                # print(mkt_prices[i])
                # cum += (mkt_prices[i] - mkt_prices[i - 1]*(1+self.fee))/ mkt_prices[i-1]
                if cur_volume < max_volume:
                    cur_volume+=1
            elif pred_move[i] == 0:
                # price go down, sell itdt_feature
                if cur_volume > 0:
                    cur_volume -=1
            else:
                # no price change
                pass
            volumes.append(cur_volume)

        volumes = np.array(volumes)
        total_trade = np.sum(np.max(volumes[1:-1] - volumes[:-2],0)) + volumes[-1]
        #total_trade = np.sum(np.maximum(volumes[1:-1] - volumes[:-2],0)) + volumes[-1]

        fee_all = 5e-3 * total_trade
        fee_all =0

        gain_total = np.array(price_changes) * np.array(volumes)
        gain_all = (np.sum(gain_total) - fee_all) / max_volume

        print(gain_ratios)
        print(pred_move)
        print(volumes)
        print(gain_all)
        print()

        ####################
        ## max retraction ##
        ####################
        # max_retract = 0.0
        # value_total = mkt_prices[1:] * np.array(volumes) / mkt_prices[1]
        # for i in range(0, num_points-2):
        #     t_m = np.min(value_total[i+1:]) - value_total[i]
        #     max_retract = np.min([t_m, max_retract])
        #
        # #print(gain_all, gain_all)
        # return gain_all, max_retract
        return gain_all

    def get_trade_pnl_from_movement_prediction_quantile_volume(self, gain_ratios, pred_move, max_volume=5):
        num_points = len(gain_ratios)
        assert len(pred_move) == num_points
        if num_points < 2:
            return 0

        volumes = []
        cur_volume = 0
        price_changes = gain_ratios[1:]/100  # original data is gain_ratio%

        # check quantile
        for i in range(0, num_points - 1):
            if pred_move[i] >= 5:
                # buy 2
                cur_volume = min(max_volume, cur_volume + 2)
            elif pred_move[i] >= 4:
                # buy 1
                cur_volume = min(max_volume, cur_volume + 1)

            elif pred_move[i] == 3:
                pass

            elif pred_move[i] >= 2:
                # sell 1
                cur_volume = max(0, cur_volume - 1)
            else:
                # sell 2
                cur_volume = max(0, cur_volume - 2)

            volumes.append(cur_volume)

        volumes = np.array(volumes)
        total_trade = np.sum(np.max(volumes[1:-1] - volumes[:-2],0)) + volumes[-1]
        fee_all = 5e-3 * total_trade
        fee_all = 0

        gain_total = np.array(price_changes) * np.array(volumes)
        gain_all = (np.sum(gain_total)-fee_all) / max_volume
        #print(gain_all, gain_all,'--2')
        return gain_all


