import os
import numpy as np
import datetime
import pickle as pkl
import torch
from torch.utils import data

vals = [-20, -10, -5, 0, 5.5, 10, 20]
mid_ind = 3
cache = {}


def get_qt(x):
    if x in cache:
        return cache[x]

    y = -1
    if x >= 0:
        for i, val in enumerate(vals[mid_ind + 1:]):
            if x < val:
                y = mid_ind + i
                break
        if y < 0:
            y = len(vals) - 1
    else:
        for i, val in enumerate(vals[:mid_ind]):
            if x < val:
                y = i
                break
        if y < 0:
            y = mid_ind
    if -100 <= x <= 100:
        cache[x] = y

    return y


def get_quantile_class(x, d3=False):
    # xs = x0 * self.price_quantile_interval_inverse
    ys = np.zeros_like(x).astype(np.int32)
    x0 = np.round(x).astype(np.int32)
    if not d3:
        for i in range(x0.shape[0]):
            y = get_qt(x0[i])
            ys[i] = y
    else:
        for i in range(x0.shape[0]):
            for j in range(x0.shape[1]):
                y = get_qt(x0[i, j])
                ys[i, j] = y
    # print(ys)
    # print(x, x0, ys)
    return ys


class public_stock_dataset_base(data.Dataset):
    public_data_path = './data/public'
    public_datasets = ['acl18', 'kdd17']
    TRAIN_FLAG, VAL_FLAG, TEST_FLAG = 0, 1, 2

    feat_gain_index = 4

    price_quantile_interval_inverse = 10


class public_stock_dataset(public_stock_dataset_base):
    """
    1) choose a segment in random for training, or
    """

    def __init__(self, dset, train_val_test_flag, hist_len, future_len, K_top, test_interval=1, ranking_mode=False):
        super(public_stock_dataset, self).__init__()
        assert dset in self.public_datasets
        dset_path = os.path.join(self.public_data_path, dset)
        with open(os.path.join(dset_path, 'stock_name_id.pkl'), 'rb') as f:
            tmp = pkl.load(f)
            stock_names, name2id, id2name = tmp
        # print(stock_names, len(stock_names))
        with open(os.path.join(dset_path, 'data.pkl'), 'rb') as f:
            dt_pv, dt_msk, dt_wd, (tra_num, val_num, tes_num) = pkl.load(f)

        self.all_data = dt_pv  # [train_val_test_flag]
        self.all_tdate = dt_wd  # [train_val_test_flag]
        self.all_mask = dt_msk  # [train_val_test_flag]

        # check paper "Enhancing Stock Movement Prediction with Adversarial Training"
        # lag size is searched with [2, 3, 4, 5, 10, 15]
        if dset == 'kdd17':
            # start from 2007, so should discard more
            self.max_lag_size = 100
        elif dset == 'acl18':
            self.max_lag_size = 15

        self.stock_names = stock_names
        self.num_stock = len(self.stock_names)
        self.name2id = name2id
        self.id2name = id2name
        self.total_trading_day = self.all_data.shape[1]
        self.total_trading_day -= self.max_lag_size
        assert self.total_trading_day > 0
        self.mode = train_val_test_flag  # 0-train, 1-val, 2-test
        # Make DOW index as index_0 and index_1, reuse current net
        # self.index_stock_id = self.name2id['DOW.csv']
        self.index_stock_id = self.name2id['SPY.csv']

        cnt_not_trade = 0
        data_index = []
        assert test_interval == 1

        if train_val_test_flag == self.TRAIN_FLAG:
            st = self.max_lag_size
            ed = dt_msk.shape[1] - future_len  # tra_num - future_len
        elif train_val_test_flag == self.VAL_FLAG:
            st = tra_num
            ed = tra_num + val_num - future_len
        else:
            st = tra_num + val_num
            ed = dt_msk.shape[1] - future_len
        assert st < ed

        for i in range(0, dt_msk.shape[0]):
            if i == self.index_stock_id:
                continue
            cnt = 0
            for j in range(st, ed, test_interval):
                if dt_msk[i, j] == 1:
                    data_index.append((i, j))
                    cnt += 1
                else:
                    cnt_not_trade += 1

        self.data_index = data_index

        self.debug = False
        assert future_len >= 1
        self.ranking_mode = ranking_mode
        if ranking_mode:
            # only in training we need cross-sectional ranking
            assert train_val_test_flag == self.TRAIN_FLAG
        self.train_val_test_flag = train_val_test_flag

        # prediction variables
        self.hist_len = hist_len
        self.future_len = future_len
        self.total_len = hist_len + future_len
        self.daily_trade_window_id_base = np.array([k for k in range(self.total_len)])
        np.seterr(all="ignore")
        print('Total instances %d = trading day %d * %d stocks - %d not trade day ' %
              (self.total_trading_day * self.num_stock, self.total_trading_day, self.num_stock, cnt_not_trade))

        self.K_top = K_top

    def __len__(self):
        """__len__"""
        return len(self.data_index)

    def set_price_quantile_interval_inverse(self, pq):
        print(self.price_quantile_interval_inverse)
        assert self.price_quantile_interval_inverse == pq

    def __getitem__(self, index: int):

        if not self.ranking_mode:
            (stock_id, day_index) = self.data_index[index]
            assert stock_id != self.index_stock_id
            stock_name = self.stock_names[stock_id]
            assert self.name2id[stock_name] == stock_id

            day_index_start = day_index - self.hist_len
            day_index_end = day_index_start + self.total_len

            calendar_ids = []
            weekday_ids = []
            for day_ind in range(day_index_start, day_index_end):
                year, month, day, weekday_id = self.all_tdate[day_ind, :]
                # calendar_id = month * 31 + day
                calendar_id = (month - 1) * 31 + (day - 1)
                calendar_ids.append(calendar_id)
                weekday_ids.append(weekday_id)
            calendar_ids = np.array(calendar_ids)
            weekday_ids = np.array(weekday_ids)

            '''
            c_open, c_high, c_low
            n_close, n_adj_close,
            5-day, 10-day, 15-day, 20-day, 25-day, 30-day
            '''
            dt = self.all_data[stock_id, day_index_start:day_index_end, :]  # (6,7)
            dt_ind = self.all_data[self.index_stock_id, day_index_start:day_index_end, :]  # (6,7)

            lbs = dt[:, -1] + 1
            lbs_ind = dt_ind[:, -1] + 1  # -1,0,1 => 0,1,2

            ratios = dt[:, self.feat_gain_index]
            # print(lbs.shape, ratios.shape)
            for lb, rt in zip(lbs, ratios):
                # print(lb, rt)
                if rt >= 0.55:
                    assert lb == 1 + 1
                elif rt < -0.5:
                    if lb != 0:
                        assert rt == -0.5
                    else:
                        assert lb == -1 + 1
                else:
                    if lb != 1:
                        # print(rt,lb)
                        assert rt == -0.5
                    else:
                        assert lb == 0 + 1

            # print(self.price_quantile_interval_inverse)
            dt_feature = dt[:, :-1] * self.price_quantile_interval_inverse
            dt_ind_feature = dt_ind[:, :-1] * self.price_quantile_interval_inverse

            hist_feature = dt_feature[:self.hist_len, :]  # [B, 5, 7]
            future_feature = dt_feature[self.hist_len:, :]  # [B, 1, 7]
            future_value = future_feature[:, self.feat_gain_index]
            future_label = lbs[self.hist_len:]
            # print(future_value)
            future_qt_label = get_quantile_class(future_value)
            # print(future_value,'---2')
            # print()

            hist_feat_ind = dt_ind_feature[:self.hist_len, :]  # [B, 5, 7]
            future_feat_ind = dt_ind_feature[self.hist_len:, :]  # [B, 1, 7]
            future_value_ind = future_feat_ind[:, self.feat_gain_index]
            future_label_ind = lbs_ind[self.hist_len:]
            future_qt_label_ind = get_quantile_class(future_value_ind)

            # print(calendar_ids.shape, weekday_ids.shape)
            # print(hist_feature.shape, future_feature.shape)
            # print(future_label.shape, future_qt_label.shape)

            return stock_id, self.index_stock_id, calendar_ids, weekday_ids, \
                   hist_feature, hist_feat_ind, \
                   future_value, future_value_ind, \
                   future_label, future_qt_label, \
                   future_label_ind, future_qt_label_ind

        else:
            # TODO: add ranking
            (_, day_index) = self.data_index[index]
            day_index_start = day_index - self.hist_len
            day_index_end = day_index_start + self.total_len

            calendar_ids = []
            weekday_ids = []
            for day_ind in range(day_index_start, day_index_end):
                year, month, day, weekday_id = self.all_tdate[day_ind, :]
                # calendar_id = month * 31 + day
                calendar_id = (month - 1) * 31 + (day - 1)
                calendar_ids.append(calendar_id)
                weekday_ids.append(weekday_id)
            calendar_ids = np.array(calendar_ids)
            weekday_ids = np.array(weekday_ids)

            msk = np.sum(self.all_mask[:, day_index_start:day_index_end], axis=1)
            indices_valid = (msk == self.total_len)
            stock_ids = np.arange(self.num_stock)
            stock_list_ids_valid = stock_ids[indices_valid]

            bsize = int(0.8 * stock_list_ids_valid.shape[0])
            indices_perm = torch.randperm(stock_list_ids_valid.shape[0])[:bsize]
            stock_list_ids_valid_perm = stock_list_ids_valid[indices_perm]
            # print(stock_list_ids_valid_perm.shape)

            dt = self.all_data[stock_list_ids_valid_perm, day_index_start:day_index_end, :]
            dt_ind = self.all_data[self.index_stock_id:self.index_stock_id + 1, day_index_start:day_index_end, :]

            dt_feature = dt[:, :, :-1] * self.price_quantile_interval_inverse
            dt_ind_feature = dt_ind[:, :, :-1] * self.price_quantile_interval_inverse

            lbs = dt[:, :, -1] + 1
            lbs_ind = dt_ind[:, :, -1] + 1

            hist_feature = dt_feature[:, :self.hist_len, :]  # [B, 5, 7]
            future_feature = dt_feature[:, self.hist_len:, :]  # [B, 1, 7]
            future_label = lbs[:, self.hist_len:]
            future_value = future_feature[:, :, self.feat_gain_index]
            future_qt_label = get_quantile_class(future_value, True)
            # ranking
            close_all = torch.tensor(future_feature[:, :, self.feat_gain_index])
            if close_all.size(0) == 0:
                print(dt.shape, bsize, stock_list_ids_valid.shape)
                print(close_all.size(), self.K_top)
                print(self.all_mask[:, day_index_start:day_index_end])
            val_1, g_sort = torch.topk(close_all, self.K_top, dim=0)
            val_2, g_sort_inv = torch.topk(close_all, self.K_top, dim=0, largest=False)

            hist_feat_ind = dt_ind_feature[:, :self.hist_len, :]  # [B, 5, 7]
            future_feat_ind = dt_ind_feature[:, self.hist_len:, :]  # [B, 1, 7]
            future_value_ind = future_feat_ind[:, :, self.feat_gain_index]
            future_label_ind = lbs_ind[:, self.hist_len:]
            future_qt_label_ind = get_quantile_class(future_value_ind, True)

            # print(future_qt_label_ind.shape, val_1.shape)

            return stock_list_ids_valid_perm, self.index_stock_id, calendar_ids, weekday_ids, \
                   hist_feature, hist_feat_ind, \
                   future_label, future_qt_label, \
                   future_label_ind, future_qt_label_ind, \
                   g_sort, g_sort_inv


class public_stock_dataset_backtest(public_stock_dataset):
    """
    1) choose a segment in random for training, or
    """

    def __init__(self, *args):
        super(public_stock_dataset_backtest, self).__init__(*args)

    def __len__(self):
        """__len__"""
        return len(self.data_index)

    def __getitem__(self, index: int):

        (stock_id, day_index) = self.data_index[index]
        assert stock_id != self.index_stock_id
        stock_name = self.stock_names[stock_id]
        assert self.name2id[stock_name] == stock_id

        day_index_start = day_index - self.hist_len
        day_index_end = day_index_start + self.total_len

        calendar_ids = []
        weekday_ids = []
        for day_ind in range(day_index_start, day_index_end):
            year, month, day, weekday_id = self.all_tdate[day_ind, :]
            # calendar_id = month * 31 + day
            calendar_id = (month - 1) * 31 + (day - 1)
            calendar_ids.append(calendar_id)
            weekday_ids.append(weekday_id)
        calendar_ids = np.array(calendar_ids)
        weekday_ids = np.array(weekday_ids)

        '''
        c_open, c_high, c_low
        n_close, n_adj_close,
        5-day, 10-day, 15-day, 20-day, 25-day, 30-day
        '''
        dt = self.all_data[stock_id, day_index_start:day_index_end, :]  # (6,7)
        dt_ind = self.all_data[self.index_stock_id, day_index_start:day_index_end, :]  # (6,7)

        lbs = dt[:, -1] + 1
        lbs_ind = dt_ind[:, -1] + 1  # -1,0,1 => 0,1,2

        ratios = dt[:, self.feat_gain_index]
        # print(lbs.shape, ratios.shape)
        for lb, rt in zip(lbs, ratios):
            # print(lb, rt)
            if rt >= 0.55:
                assert lb == 1 + 1
            elif rt < -0.5:
                if lb != 0:
                    assert rt == -0.5
                else:
                    assert lb == -1 + 1
            else:
                if lb != 1:
                    # print(rt,lb)
                    assert rt == -0.5
                else:
                    assert lb == 0 + 1

        # print(self.price_quantile_interval_inverse)
        dt_feature = dt[:, :-1] * self.price_quantile_interval_inverse
        dt_ind_feature = dt_ind[:, :-1] * self.price_quantile_interval_inverse

        hist_feature = dt_feature[:self.hist_len, :]  # [B, 5, 7]
        future_feature = dt_feature[self.hist_len:, :]  # [B, 1, 7]
        future_value = future_feature[:, self.feat_gain_index]
        future_label = lbs[self.hist_len:]
        # print(future_value)
        future_qt_label = get_quantile_class(future_value)
        # print(future_value,'---2')
        # print()

        hist_feat_ind = dt_ind_feature[:self.hist_len, :]  # [B, 5, 7]
        future_feat_ind = dt_ind_feature[self.hist_len:, :]  # [B, 1, 7]
        future_value_ind = future_feat_ind[:, self.feat_gain_index]
        future_label_ind = lbs_ind[self.hist_len:]
        future_qt_label_ind = get_quantile_class(future_value_ind)

        # print(calendar_ids.shape, weekday_ids.shape)
        # print(hist_feature.shape, future_feature.shape)
        # print(future_label.shape, future_qt_label.shape)

        return stock_id, self.index_stock_id, calendar_ids, weekday_ids, \
               hist_feature, hist_feat_ind, \
               future_value, future_value_ind, \
               future_label, future_qt_label, \
               future_label_ind, future_qt_label_ind
