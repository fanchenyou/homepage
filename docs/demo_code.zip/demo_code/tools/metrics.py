import numpy as np
from sklearn.preprocessing import normalize

#########################
##### MCC  ##############
#########################
# see Stock Movement Prediction from Tweets and Historical Prices
def mcc_metric(tp, fp, tn, fn):
    t1 = tp * tn - fp * fn
    t2 = (tp + fp)*(tp + fn)*(tn + fp)*(tn + fn)
    t3 = t1 / np.sqrt(t2)
    return t3

def mcc_metric_confusion(confusion_matrix):
    tn = confusion_matrix[0, 0]
    tp = confusion_matrix[1, 1]
    fp = confusion_matrix[0, 1]
    fn = confusion_matrix[1, 0]
    return mcc_metric(tp, fp, tn, fn)

###########################
# evaluate segmentation ###
###########################
class runningScore(object):
    def __init__(self, n_classes):
        self.n_classes = n_classes
        self.confusion_matrix = np.zeros((n_classes, n_classes))
        self.confusion_matrix_norm = None
        self.class_hist = np.zeros((n_classes))

    def update(self, label_preds, label_trues):
        for lt, lp in zip(label_trues, label_preds):
            self.confusion_matrix[lt, lp] += 1
            self.class_hist[lt] += 1

    def get_per_class_acc(self):
        accs = [self.confusion_matrix[i,i] / self.class_hist[i] for i in range(self.n_classes)]
        accs = np.round(accs, 3)
        return np.mean(accs), accs

    def reset(self):
        self.confusion_matrix = np.zeros((self.n_classes, self.n_classes))
        self.confusion_matrix_norm = None
        self.class_hist = np.zeros((self.n_classes))

    def normalize(self):
        # normalize by rows
        # each row is a gt-pred
        self.confusion_matrix_norm = normalize(self.confusion_matrix, axis=1, norm='l1')

    def print_score(self):
        print(self.confusion_matrix)

    def print_score_norm(self):
        print(self.confusion_matrix_norm)

    def print_score_norm_round(self, rd=3):
        new_confusion_matrix_norm = np.round(self.confusion_matrix_norm, decimals=rd)
        print(new_confusion_matrix_norm)

    def print_score_norm_int(self, rd=0):
        new_confusion_matrix_norm = np.round(100*self.confusion_matrix_norm, decimals=rd)
        print(new_confusion_matrix_norm)
        str = repr(new_confusion_matrix_norm)
        print(str)


    def print_class_hist(self):
        print(self.class_hist)

    def two_class_metrics(self):
        # tn, fp, fn, tp
        assert self.n_classes==2
        tn = self.confusion_matrix[0,0]
        fp = self.confusion_matrix[0,1]
        fn = self.confusion_matrix[1,0]
        tp = self.confusion_matrix[1,1]
        return tn, fp, fn, tp



###########################
# evaluate classification #
###########################
class averageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count
