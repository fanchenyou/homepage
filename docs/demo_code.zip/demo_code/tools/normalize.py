import os
import numpy as np


def exponential_smoothing(series, alpha):
    # http://ethen8181.github.io/machine-learning/time_series/1_exponential_smoothing.html
    """given a series and alpha, return series of exponentially smoothed points"""
    results = np.zeros_like(series)

    # first value remains the same as series,
    # as there is no history to learn from
    results[0] = series[0]
    for t in range(1, series.shape[0]):
        results[t] = alpha * series[t] + (1 - alpha) * results[t - 1]

    return results