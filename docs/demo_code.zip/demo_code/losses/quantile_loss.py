import numpy as np
import torch
import torch.nn.functional as F

class QuantileClassFocalLoss:
    """
    Quantile loss, i.e. a quantile of ``q=0.5`` will give half of the mean absolute error as it is calculated as
    Defined as ``max(q * (y-y_pred), (1-q) * (y_pred-y))``
    """

    def __init__(self, quantiles, device, wt0, reduction='mean'):

        """
        Quantile loss
        Args:
            quantiles: quantiles for metric, [0.02, 0.1, 0.25, 0.5, 0.75, 0.9, 0.98]
        """
        self.num_qt = len(quantiles)
        self.quantiles = quantiles
        weights = []
        for ix, qt in enumerate(quantiles):
            wt = np.zeros(self.num_qt, dtype=np.float32)
            if ix <= self.num_qt // 2:
                wt[:ix + 1] = qt / 100.0
                wt[ix + 1:] = 1 - qt / 100.0
            else:
                wt[:ix] = qt / 100.0
                wt[ix:] = 1 - qt / 100.0
            wt2 = (1-wt)
            weights.append(wt2)

        weights = np.array(weights)
        print(np.round(weights,2))

        self.weights = torch.from_numpy(weights).float().to(device) * wt0
        self.reduction = reduction
        self.gamma = 2.0
        self.device = device

    def __call__(self, input_logits: torch.Tensor, target_label: torch.Tensor) -> torch.Tensor:

        # input_logits.size() should be [B, num_quantiles, num_quantiles]
        # assert input_logits.size(1) == input_logits.size(2) == self.num_qt
        log_prob = F.log_softmax(input_logits, dim=-1)
        prob = torch.exp(log_prob)

        losses = []
        loss_all = torch.tensor([0]).float().to(self.device)
        for i, qt in enumerate(self.quantiles):
            loss = F.nll_loss(
                ((1 - prob[:,i,:]) ** self.gamma) * log_prob[:, i, :],
                target_label, weight=self.weights[i, :],
                reduction=self.reduction
            )
            losses.append(loss)
            loss_all += loss

        return loss_all / len(losses)
